@echo off
rem Right-click this file > Run as administrator
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1"
pause
