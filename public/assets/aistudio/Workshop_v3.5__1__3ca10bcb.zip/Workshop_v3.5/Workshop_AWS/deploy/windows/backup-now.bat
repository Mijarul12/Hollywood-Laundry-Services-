@echo off
rem Makes an instant copy of the database into C:\Workshop\data\backups
cd /d C:\Workshop\server
"C:\Program Files\nodejs\node.exe" -e "const n=new Date().toISOString().slice(0,16).replace(/[-:T]/g,'');require('better-sqlite3')('C:/Workshop/data/workshop.db').backup('C:/Workshop/data/backups/manual-'+n+'.db').then(()=>console.log('OK - saved manual-'+n+'.db'))"
pause
