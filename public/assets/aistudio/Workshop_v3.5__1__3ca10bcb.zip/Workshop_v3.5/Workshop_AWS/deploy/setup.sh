#!/usr/bin/env bash
# Workshop Operational Control — one-time server setup (Ubuntu 22.04 / 24.04 on AWS Lightsail)
# Run from the unzipped folder:   sudo bash deploy/setup.sh  workshop.yourdomain.com  you@email.com
set -euo pipefail
DOMAIN="${1:-}"; EMAIL="${2:-}"
if [ -z "$DOMAIN" ] || [ -z "$EMAIL" ]; then echo "Usage: sudo bash deploy/setup.sh <domain> <your email>"; exit 1; fi
HERE="$(cd "$(dirname "$0")/.." && pwd)"; APP=/opt/workshop; DATA=/var/lib/workshop

echo "== 1/5 System packages"
apt-get update -y
apt-get install -y curl ca-certificates gnupg debian-keyring debian-archive-keyring apt-transport-https sqlite3 unzip

echo "== 2/5 Node.js 20"
if ! command -v node >/dev/null || [ "$(node -v | cut -d. -f1 | tr -d v)" -lt 18 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

echo "== 3/5 Caddy (HTTPS certificate is automatic)"
if ! command -v caddy >/dev/null; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y && apt-get install -y caddy
fi

echo "== 4/5 App files"
id workshop >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin workshop
mkdir -p "$APP" "$DATA"
cp -r "$HERE/server" "$HERE/public" "$APP/"
[ -f "$APP/server/.env" ] || cp "$APP/server/.env.example" "$APP/server/.env"
cd "$APP/server" && npm install --omit=dev --no-audit --no-fund
chown -R workshop:workshop "$APP" "$DATA"; chmod 600 "$APP/server/.env"

cat > /etc/systemd/system/workshop.service <<UNIT
[Unit]
Description=Workshop Operational Control
After=network.target
[Service]
User=workshop
WorkingDirectory=$APP/server
Environment=NODE_ENV=production
Environment=DATA_DIR=$DATA
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT

cat > /etc/caddy/Caddyfile <<CADDY
{
  email $EMAIL
}
$DOMAIN {
  encode gzip
  reverse_proxy 127.0.0.1:8080
}
CADDY

echo "== 5/5 Start"
systemctl daemon-reload
systemctl enable --now workshop
systemctl restart workshop
systemctl reload caddy || systemctl restart caddy
sleep 2
if curl -fsS http://127.0.0.1:8080/healthz >/dev/null; then echo; echo "✓ Running.  Open  https://$DOMAIN   (first login: Admin / 1234)";
else echo "✗ App did not start — see:  sudo journalctl -u workshop -n 50"; fi
