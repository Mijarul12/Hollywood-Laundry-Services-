/**
 * Workshop Operational Control  (v3.3)
 * Google Apps Script web app with a Google Sheets backend.
 *
 * FIRST TIME:  Run ▶ setup  once and approve the permissions.
 * Deploy ▶ New deployment ▶ Web app ▶ Execute as: Me ▶ Who has access: Anyone.
 *
 * Data rules
 *  - Every screen saves into ONE sheet ("Entries"), tagged with its unit (UL / PC).
 *  - Uploaded files are read on the phone. Only totals are saved
 *    (the latest Workshop Out garment list is kept in "DueList" and replaced on every upload).
 */

var APP = { TZ: 'Asia/Kolkata', MAX_PIN_TRIES: 6, WINDOW: 180, PHOTO_FOLDER: 'Workshop WN Photos', BACKUP_FOLDER: 'Workshop Backups' };
var SCHEMA = 'v3.3';

var SH = { USERS: 'Users', SETTINGS: 'Settings', DAILY: 'Daily', ENT: 'Entries', LOTS: 'Lots', DUELIST: 'DueList', LOG: 'Log' };
var HEADERS = {
  Users: ['Name', 'Role', 'PIN', 'Modules', 'Active', 'Units'],
  Settings: ['Key', 'Value'],
  Daily: ['Key', 'Date', 'Unit', 'Data', 'Filled', 'Total', 'Submitted', 'UpdatedBy', 'UpdatedAt'],
  Entries: ['ID', 'Module', 'Date', 'Unit', 'Store', 'Summary', 'Data', 'By', 'At'],
  Lots: ['Key', 'Date', 'Unit', 'Type', 'Cleared', 'Log', 'UpdatedBy', 'UpdatedAt'],
  DueList: ['Due', 'Barcode', 'Store', 'Garment', 'Service', 'Unit'],
  Log: ['At', 'User', 'Action', 'Detail']
};

var ALL_MODULES = ['daily', 'rp', 'iron', 'scan', 'wn', 'saree', 'rewash', 'repair', 'washerr', 'grc', 'staffErr', 'meter', 'spot', 'quickfix', 'boiler', 'reports', 'settings'];
var OFFICE_MODULES = ['rp', 'iron', 'scan', 'wn', 'saree', 'rewash', 'repair', 'washerr', 'grc', 'meter'];
var PROCESS_MODULES = ['spot', 'quickfix', 'boiler'];
var SEED_USERS = { office: ['Sunny', 'Ajay', 'Raja', 'Naushad', 'Bikash', 'Suman', 'Raju'], process: ['Ranjit', 'Nitu', 'Dilip', 'Altaf', 'Amod', 'Munna'] };

var DEFAULT_SETTINGS = {
  units: ['UL', 'PC'],
  stores: [
    { code: 'BB', aliases: [], pc: false, email: '' }, { code: 'MG', aliases: [], pc: false, email: '' },
    { code: 'MP', aliases: [], pc: false, email: '' }, { code: 'SL', aliases: [], pc: false, email: '' },
    { code: 'AC', aliases: [], pc: true, email: '' }, { code: 'GT', aliases: ['HGT'], pc: true, email: '' },
    { code: 'LT', aliases: [], pc: true, email: '' }
  ],
  itCodes: ['IT'],
  rounds: ['Urgent', 'Lot 1 – Morning', 'Lot 2 – Evening'],
  teams: {
    office: ['Sunny', 'Ajay', 'Raja', 'Naushad', 'Bikash', 'Suman', 'Raju'],
    iron: ['Munna', 'Dilip', 'Altaf', 'Nitu', 'Ashok', 'Nathu', 'Azad'],
    wash: ['Prabhu', 'Shyam', 'Laxmi', 'Ranjit', 'Akash'],
    spot: ['Ranjit'],
    qf: ['Nitu']
  },
  rewashTypes: ['Full wash', 'Spotting'],
  garments: ['Shirt', 'T Shirt', 'Pant', 'Jeans', 'Kurta', 'Saree', 'Ladies Top', 'Coat', 'Bedsheet', 'Blanket', 'Parda', 'Carpet'],
  spotTypes: ['Oil', 'Ink', 'Colour', 'Rust', 'Food', 'Haldi'],
  repairTypes: ['Button', 'Stitch', 'Zip', 'Hem', 'Hook', 'Patch'],
  damageTypes: ['Colour bleed', 'Shrink', 'Tear / Hole', 'Stain', 'Button broken'],
  damagePoints: { 'Colour bleed': 3, 'Shrink': 3, 'Tear / Hole': 5, 'Stain': 1, 'Button broken': 1 },
  repairPlaces: ['PP'],
  sareeTo: ['Polish man'],
  extraItems: ['Garment', 'Hanger', 'Bag', 'Box', 'Cover', 'Sticker roll'],
  staffErrTypes: ['Late coming', 'Wrong packing', 'Wrong tagging', 'Garment misplaced', 'Careless work', 'Other'],
  boilers: [{ name: 'Boiler 1', unit: 'UL', staff: [] }],
  meters: [{ name: 'Electricity', measure: 'kWh' }, { name: 'Water', measure: 'KL' }],
  alerts: { admin: '', manager: '', account: '' },
  theme: 'hollywood',
  brandV: 1
};
/** lists that staff may extend from the app (+ Add) */
var STAFF_LISTS = ['teams.office', 'sareeTo', 'extraItems', 'garments', 'spotTypes', 'repairTypes', 'damageTypes', 'repairPlaces', 'staffErrTypes', 'teams.iron', 'teams.wash', 'teams.spot', 'teams.qf'];

/* ───────────────────────── Web entry ───────────────────────── */

function doGet() {
  return HtmlService.createTemplateFromFile('Index').evaluate()
    .setTitle('Workshop Operational Control')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
function include(name) { return HtmlService.createHtmlOutputFromFile(name).getContent(); }

/* ───────────────────────── Setup (safe to run again) ───────────────────────── */

function setup() { ensureSchema_(true); Logger.log('Setup done. First login: Admin / PIN 1234 — change it in Settings ▶ Users.'); }

function ensureSchema_(force) {
  var props = PropertiesService.getScriptProperties();
  if (!force && props.getProperty('SCHEMA') === SCHEMA) return;
  var lock = LockService.getScriptLock(); lock.waitLock(30000);
  try {
    if (!force && props.getProperty('SCHEMA') === SCHEMA) return;
    var ss = SpreadsheetApp.getActiveSpreadsheet() || (props.getProperty('SSID') && SpreadsheetApp.openById(props.getProperty('SSID')));
    var stamp = Utilities.formatDate(new Date(), APP.TZ, 'MMdd-HHmm');
    Object.keys(HEADERS).forEach(function (name) {
      var sh = ss.getSheetByName(name);
      if (sh && sh.getLastRow() > 0) {
        var head = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function (h) { return String(h).trim(); });
        if (head.slice(0, HEADERS[name].length).join('|') !== HEADERS[name].join('|')) { sh.setName(name + '_old_' + stamp); sh = null; }
      }
      if (!sh) sh = ss.insertSheet(name);
      if (sh.getLastRow() === 0) {
        sh.getRange(1, 1, 1, HEADERS[name].length).setValues([HEADERS[name]]).setFontWeight('bold').setBackground('#0B3B2E').setFontColor('#F4E7C5');
        sh.setFrozenRows(1);
      }
    });
    var def = ss.getSheetByName('Sheet1');
    if (def && def.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(def);

    var users = ss.getSheetByName(SH.USERS);
    if (users.getLastRow() < 2) {
      var rows = [['Admin', 'Admin', tx_('1234'), ALL_MODULES.join(','), true, 'UL,PC']];
      SEED_USERS.office.forEach(function (n) { rows.push([n, 'Staff', tx_('1111'), (n === 'Sunny' ? ['daily', 'staffErr'].concat(OFFICE_MODULES) : OFFICE_MODULES).join(','), true, 'UL']); });
      SEED_USERS.process.forEach(function (n) { rows.push([n, 'Staff', tx_('1111'), PROCESS_MODULES.join(','), true, 'UL']); });
      users.getRange(2, 1, rows.length, 6).setValues(rows);
    }
    var st = ss.getSheetByName(SH.SETTINGS);
    if (!findRows_(st, 1, 'app').length) st.appendRow(['app', JSON.stringify(DEFAULT_SETTINGS)]);
    if (!props.getProperty('SECRET')) props.setProperty('SECRET', Utilities.getUuid() + Utilities.getUuid());
    props.setProperty('SSID', ss.getId());
    props.setProperty('SCHEMA', SCHEMA);
    CacheService.getScriptCache().removeAll(['users', 'settings']);
  } finally { lock.releaseLock(); }
}

function ss_() {
  var id = PropertiesService.getScriptProperties().getProperty('SSID');
  return id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActiveSpreadsheet();
}
function sh_(name) { return ss_().getSheetByName(name); }

/* ───────────────────────── Helpers ───────────────────────── */

function tx_(v) { return "'" + v; }  // force plain text in Sheets
function today_() { return Utilities.formatDate(new Date(), APP.TZ, 'yyyy-MM-dd'); }
function nowStr_() { return Utilities.formatDate(new Date(), APP.TZ, 'yyyy-MM-dd HH:mm:ss'); }
function hmNow_() { return Utilities.formatDate(new Date(), APP.TZ, 'HH:mm'); }
function dkey_(v) { return v instanceof Date ? Utilities.formatDate(v, APP.TZ, 'yyyy-MM-dd') : String(v || '').trim(); }
function hm_(v) {
  if (v instanceof Date) return Utilities.formatDate(v, APP.TZ, 'HH:mm');
  var m = String(v || '').match(/(\d{1,2}):(\d{2})/);
  return m ? ('0' + m[1]).slice(-2) + ':' + m[2] : '';
}
function addDays_(d, n) {
  var p = d.split('-'), dt = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2]));
  dt.setUTCDate(dt.getUTCDate() + n);
  return dt.toISOString().slice(0, 10);
}
function weekStart_(d) { var p = d.split('-'); return addDays_(d, -((new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])).getUTCDay() + 6) % 7)); }
function uid_() { return 'E' + Utilities.getUuid().replace(/-/g, '').slice(0, 10).toUpperCase(); }
function num_(v) { var n = Number(v); return isFinite(n) ? n : 0; }
function validDate_(d) { if (!/^\d{4}-\d{2}-\d{2}$/.test(d || '')) throw new Error('Bad date'); return d; }
function log_(user, action, detail) { try { sh_(SH.LOG).appendRow([tx_(nowStr_()), user, action, String(detail || '').slice(0, 500)]); } catch (e) { } }
function withLock_(fn) { var l = LockService.getScriptLock(); l.waitLock(20000); try { return fn(); } finally { l.releaseLock(); } }
function jparse_(s, d) { try { return JSON.parse(s || ''); } catch (e) { return d; } }
function str_(v) { return String(v == null ? '' : v).trim(); }

function findRows_(sheet, col, key) {
  var last = sheet.getLastRow();
  if (last < 2) return [];
  var found = sheet.getRange(2, col, last - 1, 1).createTextFinder(key).matchEntireCell(true).findAll();
  var width = sheet.getLastColumn();
  return found.map(function (r) { var row = r.getRow(); return { row: row, values: sheet.getRange(row, 1, 1, width).getValues()[0] }; });
}
/** rows whose date column (1-based) is within from..to — reads from the bottom up (data is mostly chronological) */
function rowsInRange_(sheet, col, from, to) {
  var last = sheet.getLastRow();
  if (last < 2) return [];
  var width = sheet.getLastColumn(), block = 4000, start = Math.max(2, last - block + 1), out = [];
  while (true) {
    var vals = sheet.getRange(start, 1, last - start + 1, width).getValues(), minSeen = '9999', part = [];
    for (var i = 0; i < vals.length; i++) {
      var d = dkey_(vals[i][col - 1]);
      if (d && d < minSeen) minSeen = d;
      if (d >= from && d <= to) part.push(vals[i]);
    }
    out = part.concat(out);
    if (start === 2 || minSeen < addDays_(from, -7)) break;
    last = start - 1; start = Math.max(2, last - block + 1);
  }
  return out;
}

/* ───────────────────────── Users / Settings ───────────────────────── */

function users_() {
  var c = CacheService.getScriptCache(), hit = c.get('users');
  if (hit) return JSON.parse(hit);
  var sh = sh_(SH.USERS), last = sh.getLastRow(), list = [];
  if (last >= 2) {
    list = sh.getRange(2, 1, last - 1, 6).getValues().map(function (r) {
      var role = str_(r[1]);
      return {
        name: str_(r[0]), role: ['Admin', 'Manager', 'Staff'].indexOf(role) >= 0 ? role : 'Staff', pin: str_(r[2]),
        modules: str_(r[3]).split(',').map(str_).filter(function (m) { return ALL_MODULES.indexOf(m) >= 0; }),
        active: !(r[4] === false || String(r[4]).toUpperCase() === 'FALSE'),
        units: str_(r[5]).split(',').map(str_).filter(String)
      };
    }).filter(function (u) { return u.name; });
  }
  c.put('users', JSON.stringify(list), 600);
  return list;
}
function findUser_(name) { var n = str_(name).toLowerCase(); return users_().filter(function (u) { return u.active && u.name.toLowerCase() === n; })[0]; }
function isMgr_(u) { return u.role === 'Admin' || u.role === 'Manager'; }
function modulesFor_(u) {
  if (isMgr_(u)) return ALL_MODULES.slice();
  return (u.modules.length ? u.modules : OFFICE_MODULES).filter(function (x) { return x !== 'settings' && x !== 'reports'; });
}
function unitsFor_(u) {
  var all = settings_().units || ['UL'];
  if (u.role === 'Admin' || !u.units.length) return all.slice();
  var l = u.units.filter(function (x) { return all.indexOf(x) >= 0; });
  return l.length ? l : [all[0]];
}
/** the unit of a request — must be one the user is allowed. Managers may ask for ALL (reports). */
function unit_(u, p, allowAll) {
  var x = str_(p.unit).toUpperCase();
  if (x === 'ALL' && allowAll && isMgr_(u)) return 'ALL';
  if (unitsFor_(u).indexOf(x) < 0) throw new Error('No access to unit ' + (x || '?'));
  return x;
}
function settings_() {
  var c = CacheService.getScriptCache(), hit = c.get('settings');
  if (hit) return JSON.parse(hit);
  var r = findRows_(sh_(SH.SETTINGS), 1, 'app')[0];
  var s = (r ? jparse_(r.values[1], null) : null) || JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  Object.keys(DEFAULT_SETTINGS).forEach(function (k) { if (s[k] === undefined) s[k] = JSON.parse(JSON.stringify(DEFAULT_SETTINGS[k])); });
  Object.keys(DEFAULT_SETTINGS.teams).forEach(function (k) { if (!s.teams[k]) s.teams[k] = DEFAULT_SETTINGS.teams[k].slice(); });
  if (s.brandV !== 1) { s.theme = 'hollywood'; s.brandV = 1; }   // switch to the Hollywood brand colours once
  c.put('settings', JSON.stringify(s), 600);
  return s;
}
function writeSettings_(s) {
  var sh = sh_(SH.SETTINGS), r = findRows_(sh, 1, 'app')[0];
  if (r) sh.getRange(r.row, 2).setValue(JSON.stringify(s)); else sh.appendRow(['app', JSON.stringify(s)]);
  CacheService.getScriptCache().remove('settings');
}

/* ───────────────────────── Auth (typed name + PIN, valid till midnight) ───────────────────────── */

function sign_(payload) {
  var secret = PropertiesService.getScriptProperties().getProperty('SECRET');
  if (!secret) throw new Error('Run setup() first');
  return Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(payload, secret)).replace(/=+$/, '');
}
function makeToken_(u) {
  var body = Utilities.base64EncodeWebSafe(JSON.stringify({ n: u.name, r: u.role, d: today_() })).replace(/=+$/, '');
  return body + '.' + sign_(body);
}
function checkToken_(token) {
  if (!token || token.indexOf('.') < 0) throw new Error('AUTH');
  var parts = token.split('.');
  if (sign_(parts[0]) !== parts[1]) throw new Error('AUTH');
  var pad = parts[0] + '==='.slice((parts[0].length + 3) % 4);
  var p = JSON.parse(Utilities.newBlob(Utilities.base64DecodeWebSafe(pad)).getDataAsString());
  if (p.d !== today_()) throw new Error('AUTH');
  var u = findUser_(p.n);
  if (!u || u.role !== p.r) throw new Error('AUTH');
  return u;
}
function need_(u, mod) { if (modulesFor_(u).indexOf(mod) < 0) throw new Error('No access'); }
/** entry date — staff can only enter today (no back-date) */
function dateFor_(u, d) {
  d = d || today_(); validDate_(d);
  if (!isMgr_(u) && d !== today_()) throw new Error("Staff can only enter today's data");
  if (d > today_()) throw new Error('Future date not allowed');
  return d;
}
function seeDate_(u, d) {
  d = d || today_(); validDate_(d);
  if (!isMgr_(u) && d !== today_()) throw new Error('Staff can only see today');
  return d;
}
function me_(u) { return { name: u.name, role: u.role, modules: modulesFor_(u), units: unitsFor_(u) }; }
function login_(p) {
  var name = str_(p.name), c = CacheService.getScriptCache(), k = 'try_' + name.toLowerCase(), n = num_(c.get(k));
  if (n >= APP.MAX_PIN_TRIES) throw new Error('Too many wrong tries. Wait 15 minutes.');
  var u = findUser_(name);
  if (!u || String(p.pin) !== u.pin) { c.put(k, String(n + 1), 900); throw new Error('Wrong name or PIN'); }
  c.remove(k);
  log_(u.name, 'login', '');
  return { token: makeToken_(u), me: me_(u), today: today_() };
}

/* ───────────────────────── API dispatcher ───────────────────────── */

function api(req) {
  try {
    req = req || {};
    ensureSchema_(false);
    var a = req.action, p = req.p || {};
    if (a === 'boot') return ok_({ today: today_(), theme: settings_().theme || 'emerald' });
    if (a === 'login') return ok_(login_(p));
    var u = checkToken_(req.token);
    switch (a) {
      case 'init': return ok_({ me: me_(u), settings: settings_(), today: today_() });
      case 'home': return ok_(home_(u, unit_(u, p)));
      case 'daily.get': need_(u, 'daily'); return ok_(dailyGet_(u, p));
      case 'daily.save': need_(u, 'daily'); return ok_(dailySave_(u, p));
      case 'daily.row': need_(u, 'daily'); return ok_(dailyRowAdd_(u, p));
      case 'daily.rowdel': need_(u, 'daily'); return ok_(dailyRowDel_(u, p));
      case 'lot.update': need_(u, 'daily'); return ok_(lotUpdate_(u, p));
      case 'lot.create': need_(u, 'daily'); return ok_(lotCreate_(u, p));
      case 'e.get': need_(u, p.mod); return ok_(modGet_(u, p.mod, unit_(u, p), seeDate_(u, p.date)));
      case 'e.add': need_(u, p.mod); return ok_(eAdd_(u, p));
      case 'e.update': need_(u, p.mod); return ok_(eUpdate_(u, p));
      case 'e.del': need_(u, p.mod); return ok_(eDel_(u, p));
      case 'iron.save': need_(u, 'iron'); return ok_(ironSave_(u, p));
      case 'rewash.save': need_(u, 'rewash'); return ok_(rewashSave_(u, p));
      case 'repair.step': need_(u, 'repair'); return ok_(repairStep_(u, p));
      case 'saree.receive': need_(u, 'saree'); return ok_(sareeReceive_(u, p));
      case 'wn.adjust': need_(u, 'wn'); return ok_(wnAdjust_(u, p));
      case 'photo': return ok_(photo_(u, p));
      case 'backup.stats': if (u.role !== 'Admin') throw new Error('Admin only'); return ok_(backupStats_());
      case 'backup.export': if (u.role !== 'Admin') throw new Error('Admin only'); return ok_(backupExport_(u));
      case 'backup.exportAll': if (u.role !== 'Admin') throw new Error('Admin only'); return ok_(backupExportAll_(u));
      case 'backup.import': if (u.role !== 'Admin') throw new Error('Admin only'); return ok_(backupImport_(u, p));
      case 'boiler.tap': need_(u, 'boiler'); return ok_(boilerTap_(u, p));
      case 'meter.save': need_(u, 'meter'); return ok_(meterSave_(u, p));
      case 'grc.save': need_(u, 'grc'); return ok_(grcSave_(u, p));
      case 'scan.upload': need_(u, 'scan'); return ok_(scanUpload_(u, p));
      case 'due.upload': need_(u, 'scan'); return ok_(dueUpload_(u, p));
      case 'list.add': return ok_(listAdd_(u, p));
      case 'report': need_(u, 'reports'); return ok_(report_(u, p));
      case 'settings.save': need_(u, 'settings'); return ok_(settingsSave_(u, p));
      case 'users.list': if (u.role !== 'Admin') throw new Error('Admin only'); return ok_(usersList_());
      case 'users.save': if (u.role !== 'Admin') throw new Error('Admin only'); return ok_(usersSave_(u, p));
    }
    throw new Error('Unknown action');
  } catch (e) {
    return { ok: false, error: String(e && e.message || e) };
  }
}
function ok_(data) { return { ok: true, data: data }; }
function lockedMsg_() { return 'Saved entries can be changed only by Manager'; }

/* ───────────────────────── Entries (one sheet for every screen) ───────────────────────── */

function eRow_(v) {
  return { id: String(v[0]), mod: String(v[1]), date: dkey_(v[2]), unit: String(v[3] || ''), store: String(v[4] || ''),
    summary: String(v[5] || ''), data: jparse_(v[6], {}), by: String(v[7] || ''), at: hm_(v[8]), stamp: String(v[8] || '') };
}
function eRange_(from, to, mod, unit) {
  var mods = mod ? [].concat(mod) : null;
  return rowsInRange_(sh_(SH.ENT), 3, from, to).map(eRow_).filter(function (e) {
    return (!mods || mods.indexOf(e.mod) >= 0) && (!unit || unit === 'ALL' || e.unit === unit || e.unit === 'ALL');
  }).sort(function (a, b) { return (a.date + a.stamp) < (b.date + b.stamp) ? -1 : 1; });
}
function eMake_(u, mod, date, unit, store, summary, data) {
  return [uid_(), mod, tx_(date), unit, str_(store), String(summary || '').slice(0, 300), JSON.stringify(data || {}), u.name, tx_(nowStr_())];
}
function eAppend_(rows) { if (!rows.length) return; var sh = sh_(SH.ENT); sh.getRange(sh.getLastRow() + 1, 1, rows.length, 9).setValues(rows); }
function eFind_(id) { var r = findRows_(sh_(SH.ENT), 1, String(id))[0]; if (!r) throw new Error('Not found'); return { row: r.row, e: eRow_(r.values) }; }
function eWrite_(row, e) { sh_(SH.ENT).getRange(row, 5, 1, 3).setValues([[e.store, String(e.summary).slice(0, 300), JSON.stringify(e.data)]]); }

/** Each simple screen: check an item and build {store, summary, data} */
var HOOK = {
  rp: function (u, unit, x) {
    var names = isMgr_(u) ? (x.names || []).map(str_).filter(String) : [u.name];
    if (!str_(x.round) || !str_(x.store) || ['Release', 'Pack'].indexOf(x.type) < 0) throw new Error('Choose round, store and Release / Pack');
    if (!names.length) throw new Error('Choose at least one name');
    var d = { round: str_(x.round), type: x.type, names: names };
    return { store: x.store, summary: d.round + ' · ' + x.store + ' · ' + x.type + ' · ' + names.join(', '), data: d };
  },
  wn: function (u, unit, x, date) {
    var d;
    if (x.kind === 'tag') {
      need3_(x, ['tag', 'store']);
      d = { kind: 'tag', tag: str_(x.tag).toUpperCase(), garment: str_(x.garment), note: str_(x.note), status: 'Pending' };
      var al = { tag: d.tag, st: str_(x.store), g: d.garment, note: d.note, at: hmNow_() };
      sendAlert_(u, 'wntag', date, unit, al); d.mail = al.mail;
      return { store: x.store, summary: 'Detached tag ' + d.tag + ' · ' + x.store + (d.garment ? ' · ' + d.garment : ''), data: d };
    }
    need3_(x, ['garment', 'karigar']);
    var photos = [].concat(x.photos || x.photo || []).map(str_).filter(String).slice(0, 2);
    if (!photos.length) throw new Error('Take a photo of the garment');
    d = { kind: 'garment', garment: str_(x.garment), karigar: str_(x.karigar), photo: photos[0], photos: photos, note: str_(x.note), status: 'Pending' };
    return { store: '', summary: 'WN ' + d.garment + ' · ironed by ' + d.karigar, data: d };
  },
  saree: function (u, unit, x, date) {
    var q = Math.round(num_(x.qty));
    if (!str_(x.to)) throw new Error('Choose to whom sent');
    if (q < 1) throw new Error('Enter quantity');
    var d = { to: str_(x.to), qty: q, note: str_(x.note), status: 'Sent', sentAt: date + ' ' + hmNow_() };
    return { store: '', summary: 'Sent ' + q + ' sarees → ' + d.to, data: d };
  },
  repair: function (u, unit, x, date) {
    need3_(x, ['store', 'garment', 'tag', 'damage']);
    var d = { garment: x.garment, tag: str_(x.tag).toUpperCase(), damage: x.damage, sentTo: str_(x.sentTo) || 'PP', note: str_(x.note), status: 'Sent', sentAt: date + ' ' + hmNow_() };
    return { store: x.store, summary: x.store + ' · ' + d.tag + ' · ' + d.garment + ' · ' + d.damage + ' → ' + d.sentTo, data: d };
  },
  spot: function (u, unit, x) {
    need3_(x, ['store', 'garment', 'spot', 'tag', 'by']);
    var d = { garment: x.garment, spot: x.spot, tag: str_(x.tag).toUpperCase(), pct: Math.max(0, Math.min(100, Math.round(num_(x.pct)))), by: x.by };
    return { store: x.store, summary: x.store + ' · ' + d.tag + ' · ' + d.garment + ' · ' + d.spot + ' → ' + d.pct + '%', data: d };
  },
  quickfix: function (u, unit, x) {
    need3_(x, ['store', 'garment', 'repair', 'kind', 'tag', 'by']);
    var d = { garment: x.garment, repair: x.repair, kind: x.kind === 'IR' ? 'IR' : 'QF', tag: str_(x.tag).toUpperCase(), by: x.by };
    return { store: x.store, summary: x.store + ' · ' + d.tag + ' · ' + d.garment + ' · ' + d.repair + ' (' + d.kind + ')', data: d };
  },
  washerr: function (u, unit, x) {
    need3_(x, ['store', 'tag', 'garment', 'damage', 'by']);
    var pt = Math.round(num_(x.points)); if (!(pt >= 1 && pt <= 10)) pt = num_((settings_().damagePoints || {})[x.damage]) || 1;
    var d = { tag: str_(x.tag).toUpperCase(), garment: x.garment, damage: x.damage, points: pt, by: x.by, note: str_(x.note) };
    return { store: x.store, summary: x.store + ' · ' + d.tag + ' · ' + d.garment + ' · ' + d.damage + ' (' + pt + ' pts) · ' + d.by, data: d };
  },
  staffErr: function (u, unit, x) {
    need3_(x, ['staff', 'note']);
    var d = { staff: str_(x.staff), note: str_(x.note), src: str_(x.src) };
    return { store: '', summary: d.staff + ' · ' + d.note, data: d };
  }
};
function need3_(x, keys) { keys.forEach(function (k) { if (!str_(x[k])) throw new Error('Fill all boxes'); }); }

function eAdd_(u, p) {
  var mod = p.mod, H = HOOK[mod];
  if (!H) throw new Error('Bad screen');
  var unit = unit_(u, p), date = dateFor_(u, p.date), items = p.items || [];
  if (!items.length) throw new Error('Nothing to save');
  return withLock_(function () {
    var rows = items.map(function (x) { var r = H(u, unit, x, date); return eMake_(u, mod, date, unit, r.store, r.summary, r.data); });
    eAppend_(rows);
    log_(u.name, mod + '.add', rows.length + ' rows');
    var out = modGet_(u, mod, unit, date); out.added = rows.map(function (r) { return r[0]; }); return out;
  });
}
function eUpdate_(u, p) {
  if (!isMgr_(u)) throw new Error(lockedMsg_());
  return withLock_(function () {
    var f = eFind_(p.id), H = HOOK[f.e.mod];
    if (!H || f.e.mod !== p.mod) throw new Error('Cannot edit this entry');
    var r = H(u, f.e.unit, p.data || {}, f.e.date), keep = f.e.data;
    if (f.e.mod === 'repair') ['status', 'sentAt', 'backAt', 'backBy', 'releasedAt', 'releasedBy'].forEach(function (k) { if (keep[k] !== undefined) r.data[k] = keep[k]; });
    if (f.e.mod === 'wn') ['status', 'inv', 'adjStore', 'adjAt', 'adjBy', 'link', 'photo', 'photos', 'mail'].forEach(function (k) { if (keep[k] !== undefined && (k !== 'photo' || !r.data.photo)) r.data[k] = keep[k]; });
    if (f.e.mod === 'saree') ['status', 'sentAt', 'recvQty', 'recvAt', 'recvBy', 'reason', 'diff'].forEach(function (k) { if (keep[k] !== undefined) r.data[k] = keep[k]; });
    f.e.store = str_(r.store); f.e.summary = r.summary; f.e.data = r.data;
    eWrite_(f.row, f.e); log_(u.name, 'e.update', f.e.id);
    return modGet_(u, f.e.mod, f.e.unit, f.e.date);
  });
}
/** delete — Manager any time; staff can undo their OWN entry within 5 minutes of saving */
function eDel_(u, p) {
  var ids = [].concat(p.ids || p.id || []).map(String).filter(String);
  if (!ids.length) throw new Error('Not found');
  return withLock_(function () {
    var last = null, nowMs = new Date().getTime();
    ids.forEach(function (id) {
      var f = eFind_(id);
      if (!isMgr_(u)) {
        var t = f.e.stamp.replace(' ', 'T') + '+05:30', age = (nowMs - new Date(t).getTime()) / 60000;
        if (f.e.by !== u.name || !(age >= 0 && age <= 5)) throw new Error(lockedMsg_());
        if (['repair', 'saree', 'wn'].indexOf(f.e.mod) >= 0 && f.e.data.status !== (f.e.mod === 'saree' ? 'Sent' : f.e.mod === 'repair' ? 'Sent' : 'Pending')) throw new Error(lockedMsg_());
      }
      sh_(SH.ENT).deleteRow(f.row); log_(u.name, isMgr_(u) ? 'e.del' : 'e.undo', f.e.mod + ' ' + f.e.summary);
      if (f.e.mod === 'due') { var l = latestDue_(f.e.date); if (!l) clearDueList_(); }
      last = f.e;
    });
    var unit = last.unit === 'ALL' ? unitsFor_(u)[0] : last.unit;
    return modGet_(u, p.mod || last.mod, unit, last.date);
  });
}

/** data for one screen on one day */
function modGet_(u, mod, unit, date) {
  var mods = mod === 'scan' ? ['scan', 'due'] : mod;
  var out = { mod: mod, unit: unit, date: date, rows: eRange_(date, date, mods, mod === 'scan' ? 'ALL' : unit) };
  if (EXTRA[mod]) EXTRA[mod](out, u, unit, date);
  return out;
}
var EXTRA = {
  rewash: function (o, u, unit, date) { o.state = rewashState_(unit, date); },
  repair: function (o, u, unit) { o.open = openItems_('repair', unit); },
  wn: function (o, u, unit, date) { o.open = openItems_('wn', unit); o.adjToday = eRange_(addDays_(date, -APP.WINDOW), date, 'wn', unit).filter(function (e) { return String(e.data.adjAt || '').slice(0, 10) === date; }); },
  saree: function (o, u, unit, date) { o.open = openItems_('saree', unit); o.recvToday = eRange_(addDays_(date, -APP.WINDOW), date, 'saree', unit).filter(function (e) { return String(e.data.recvAt || '').slice(0, 10) === date; }); },
  boiler: function (o, u, unit, date) { o.open = boilerOpen_(unit); o.week = eRange_(addDays_(date, -6), date, 'boiler', unit); },
  meter: function (o, u, unit, date) { o.last = meterLast_(unit, date); },
  iron: function (o, u, unit, date) { var ws = weekStart_(date); o.weekStart = ws; o.week = eRange_(ws, date, 'iron', unit); },
  grc: function (o, u, unit, date) { o.yesterday = eRange_(addDays_(date, -1), addDays_(date, -1), 'grc', unit)[0] || null; },
  scan: function (o, u, unit, date) {
    var my = unitsFor_(u);
    o.rows = o.rows.filter(function (e) { return e.mod === 'due' || my.indexOf(e.unit) >= 0; });
    var last = {};
    eRange_(addDays_(date, -13), date, 'due', 'ALL').forEach(function (e) { last[e.date] = e; });
    o.history = Object.keys(last).sort().map(function (k) { var d = last[k].data; return { date: k, total: d.total, ul: d.UL, pc: d.PC, overdue: d.od }; });
    o.list = date === today_() ? dueList_() : [];
  }
};

/** items still open — looks back APP.WINDOW days.
 *  repair: not yet released to store; shown to the sending unit AND to the unit it was sent to (UL ↔ PC)
 *  saree : sent for polish, not yet received back */
function openItems_(mod, unit) {
  var t = today_();
  return eRange_(addDays_(t, -APP.WINDOW), t, mod, mod === 'repair' ? 'ALL' : unit).filter(function (e) {
    if (mod === 'repair') return e.data.status !== 'Released' && (unit === 'ALL' || e.unit === unit || e.data.sentTo === unit);
    if (mod === 'saree') return e.data.status !== 'Received';
    if (mod === 'wn') return e.data.status !== 'Adjusted';
    return true;
  });
}

/* ───────────────────────── Ironmen errors — one screen, all karigars ───────────────────────── */

function ironSave_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date);
  var items = (p.items || []).map(function (x) { return { k: str_(x.karigar), pts: Math.round(num_(x.points)), note: str_(x.note) }; }).filter(function (x) { return x.k && (x.pts > 0 || x.note); });
  if (!items.length) throw new Error('Enter points for at least one karigar');
  return withLock_(function () {
    var rows = items.map(function (x) { return eMake_(u, 'iron', date, unit, '', x.k + ' · ' + x.pts + ' pts' + (x.note ? ' · ' + x.note : ''), { karigar: x.k, points: x.pts, note: x.note }); });
    eAppend_(rows);
    log_(u.name, 'iron.save', items.length + ' karigars');
    var out = modGet_(u, 'iron', unit, date); out.added = rows.map(function (r) { return r[0]; }); return out;
  });
}

/* ───────────────────────── Rewash — given / received, balance carried forward (oldest first) ───────────────────────── */

function rewashState_(unit, upto) {
  var kinds = {};
  (settings_().rewashTypes || ['Full wash', 'Spotting']).forEach(function (k) { kinds[k] = { given: 0, received: 0, lots: [] }; });
  eRange_(addDays_(upto, -APP.WINDOW), upto, 'rewash', unit).forEach(function (e) {
    var k = e.data.kind || 'Full wash', K = kinds[k] = kinds[k] || { given: 0, received: 0, lots: [] }, q = num_(e.data.qty);
    if (e.data.type === 'Given') { K.given += q; K.lots.push({ date: e.date, qty: q, left: q }); }
    else { K.received += q; var rem = q; K.lots.forEach(function (l) { var t = Math.min(l.left, rem); l.left -= t; rem -= t; }); }
  });
  var out = {};
  Object.keys(kinds).forEach(function (k) {
    var K = kinds[k], byDate = {};
    K.lots.forEach(function (l) { if (l.left > 0) { var b = byDate[l.date] = byDate[l.date] || { date: l.date, given: 0, left: 0 }; b.given += l.qty; b.left += l.left; } });
    var pending = Object.keys(byDate).sort().map(function (d) { return byDate[d]; });
    out[k] = { balance: pending.reduce(function (t, x) { return t + x.left; }, 0), pending: pending };
  });
  return out;
}
function rewashSave_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date);
  var by = isMgr_(u) ? str_(p.by) : u.name;
  if (!by) throw new Error('Choose who did it');
  var lines = (p.lines || []).map(function (l) { return { kind: str_(l.kind), given: Math.max(0, Math.round(num_(l.given))), received: Math.max(0, Math.round(num_(l.received))) }; })
    .filter(function (l) { return l.kind && (l.given || l.received); });
  if (!lines.length) throw new Error('Enter quantity');
  return withLock_(function () {
    var st = rewashState_(unit, date), rows = [];
    lines.forEach(function (l) {
      var bal = (st[l.kind] ? st[l.kind].balance : 0) + l.given;
      if (l.received > bal) throw new Error(l.kind + ': received ' + l.received + ' but only ' + bal + ' pending');
      if (l.given) rows.push(eMake_(u, 'rewash', date, unit, '', l.kind + ' · Given · ' + l.given + ' pcs · ' + by, { kind: l.kind, type: 'Given', qty: l.given, by: by }));
      if (l.received) rows.push(eMake_(u, 'rewash', date, unit, '', l.kind + ' · Received · ' + l.received + ' pcs · ' + by, { kind: l.kind, type: 'Received', qty: l.received, by: by }));
    });
    eAppend_(rows); log_(u.name, 'rewash.save', JSON.stringify(lines));
    var out = modGet_(u, 'rewash', unit, date); out.added = rows.map(function (r) { return r[0]; }); return out;
  });
}

/* ───────────────────────── Repair follow-up: Sent → Back → Released ───────────────────────── */

function repairStep_(u, p) {
  var unit = unit_(u, p);
  return withLock_(function () {
    var f = eFind_(p.id), d = f.e.data, stamp = today_() + ' ' + hmNow_();
    if (f.e.mod !== 'repair' || (f.e.unit !== unit && f.e.data.sentTo !== unit && !isMgr_(u))) throw new Error('Not found');
    if (p.step === 'Back') { if (d.backAt) throw new Error('Already marked back'); d.status = 'Back'; d.backAt = stamp; d.backBy = u.name; }
    else if (p.step === 'Released') { if (d.status === 'Released') throw new Error('Already released'); if (!d.backAt) { d.backAt = stamp; d.backBy = u.name; } d.status = 'Released'; d.releasedAt = stamp; d.releasedBy = u.name; }
    else throw new Error('Bad step');
    eWrite_(f.row, f.e); log_(u.name, 'repair.' + p.step, f.e.id);
    return modGet_(u, 'repair', unit, today_());
  });
}

/* ───────────────────────── Saree polish: sent (to whom) → received back; difference needs a reason ───────────────────────── */

function sareeReceive_(u, p) {
  var unit = unit_(u, p), q = Math.round(num_(p.qty)), date = dateFor_(u, p.date);
  if (q < 0) throw new Error('Enter quantity');
  return withLock_(function () {
    var f = eFind_(p.id), d = f.e.data;
    if (f.e.mod !== 'saree' || f.e.unit !== unit) throw new Error('Not found');
    if (d.status === 'Received') throw new Error('Already received');
    var diff = q - num_(d.qty);
    if (diff !== 0 && !str_(p.reason)) throw new Error('Sent ' + d.qty + ', received ' + q + ' — write the reason for the difference');
    d.status = 'Received'; d.recvQty = q; d.diff = diff; d.reason = str_(p.reason); d.recvAt = date + ' ' + hmNow_(); d.recvBy = u.name;
    f.e.summary = 'Sent ' + d.qty + ' → ' + d.to + ' · received ' + q + (diff ? ' (' + (diff > 0 ? '+' : '') + diff + ': ' + d.reason + ')' : '');
    eWrite_(f.row, f.e); log_(u.name, 'saree.receive', f.e.id + ' ' + q);
    return modGet_(u, 'saree', unit, date);
  });
}

/* ───────────────────────── Boilers — many boilers, many start / stop sessions ───────────────────────── */

function mins_(a, b) { var x = a.split(':'), y = b.split(':'), m = (+y[0] * 60 + +y[1]) - (+x[0] * 60 + +x[1]); return m < 0 ? m + 1440 : m; }
function hmTxt_(m) { return Math.floor(m / 60) + 'h ' + ('0' + (m % 60)).slice(-2) + 'm'; }
function boilerOpen_(unit) {
  var out = {}, t = today_();
  eRange_(addDays_(t, -1), t, 'boiler', unit).forEach(function (e) { if (e.data.start && !e.data.stop) out[e.data.boiler] = e; });
  return out;
}
function boilerTap_(u, p) {
  var unit = unit_(u, p), date = today_(), time = hmNow_(), b = str_(p.boiler);
  var bo = (settings_().boilers || []).filter(function (x) { return x.name === b; })[0];
  if (!bo) throw new Error('Unknown boiler');
  if (!isMgr_(u) && (bo.staff || []).length && bo.staff.indexOf(u.name) < 0) throw new Error(b + ' is not given to you');
  return withLock_(function () {
    var open = boilerOpen_(unit)[b];
    if (p.what === 'start') {
      if (open) throw new Error(b + ' is already running since ' + open.data.start);
      eAppend_([eMake_(u, 'boiler', date, unit, '', b + ' · Start ' + time + ' · ' + u.name, { boiler: b, start: time, by: u.name })]);
    } else {
      if (!open) throw new Error(b + ' is not running');
      var f = eFind_(open.id), d = f.e.data;
      d.stop = time; d.stopBy = u.name; d.mins = mins_(d.start, time);
      f.e.summary = b + ' · ' + d.start + ' – ' + time + ' (' + hmTxt_(d.mins) + ')';
      eWrite_(f.row, f.e);
    }
    log_(u.name, 'boiler.' + p.what, b);
    return modGet_(u, 'boiler', unit, date);
  });
}

/* ───────────────────────── Electricity & water meters — last reading carried forward ───────────────────────── */

function meterLast_(unit, date) {
  var out = {};
  eRange_(addDays_(date, -APP.WINDOW), addDays_(date, -1), 'meter', unit).forEach(function (e) {
    Object.keys(e.data.readings || {}).forEach(function (m) { out[m] = { date: e.date, reading: num_(e.data.readings[m]) }; });
  });
  return out;
}
function meterSave_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date), rd = p.readings || {}, last = meterLast_(unit, date), readings = {}, used = {};
  (settings_().meters || []).forEach(function (m) {
    var v = str_(rd[m.name]); if (v === '') return;
    var x = num_(v); if (x < 0) throw new Error('Bad reading for ' + m.name);
    if (last[m.name] && x < last[m.name].reading && !p.force) throw new Error(m.name + ': today ' + x + ' is lower than last ' + last[m.name].reading + '. Check the reading.');
    readings[m.name] = x; used[m.name] = last[m.name] ? Math.round((x - last[m.name].reading) * 100) / 100 : null;
  });
  if (!Object.keys(readings).length) throw new Error('Enter a reading');
  var sum = Object.keys(readings).map(function (k) { return k + ' ' + readings[k] + (used[k] != null ? ' (used ' + used[k] + ')' : ''); }).join(' · ');
  return upsert_(u, 'meter', unit, date, { readings: readings, used: used }, sum);
}
/* GRC count — one entry per day per unit with the count of every store */
function grcSave_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date), counts = {}, total = 0;
  Object.keys(p.counts || {}).forEach(function (s) { var v = str_(p.counts[s]); if (v === '') return; var n = Math.max(0, Math.round(num_(v))); counts[s] = n; total += n; });
  if (!Object.keys(counts).length) throw new Error('Enter at least one store');
  return upsert_(u, 'grc', unit, date, { counts: counts, total: total }, 'GRC ' + total + ' · ' + Object.keys(counts).map(function (s) { return s + ' ' + counts[s]; }).join(', '));
}
function upsert_(u, mod, unit, date, data, summary) {
  return withLock_(function () {
    var cur = eRange_(date, date, mod, unit).filter(function (e) { return e.unit === unit; })[0];
    if (cur) {
      if (!isMgr_(u)) throw new Error(lockedMsg_());
      var f = eFind_(cur.id); f.e.data = data; f.e.summary = summary; eWrite_(f.row, f.e);
    } else eAppend_([eMake_(u, mod, date, unit, '', summary, data)]);
    log_(u.name, mod + '.save', summary);
    return modGet_(u, mod, unit, date);
  });
}

/* ───────────────────────── Scanned (Delivery Note Summary) — only totals ───────────────────────── */

function storeMap_() {
  var m = {};
  settings_().stores.forEach(function (s) { m[s.code.toUpperCase()] = s; (s.aliases || []).forEach(function (a) { m[str_(a).toUpperCase()] = s; }); });
  return m;
}
function scanUpload_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date), notes = (p.notes || []).map(String).filter(String), smap = storeMap_();
  var stores = {}, total = 0;
  Object.keys(p.stores || {}).forEach(function (raw) {
    var so = smap[str_(raw).toUpperCase()], code = so ? so.code : str_(raw).toUpperCase(), q = Math.max(0, Math.round(num_(p.stores[raw])));
    if (!code || !q) return; stores[code] = (stores[code] || 0) + q; total += q;
  });
  if (!total) throw new Error('No garments found in the file');
  return withLock_(function () {
    if (notes.length) {
      var seen = {};
      eRange_(addDays_(date, -10), date, 'scan', 'ALL').forEach(function (e) { (e.data.notes || []).forEach(function (n) { seen[n] = e; }); });
      var dup = notes.filter(function (n) { return seen[n]; });
      if (dup.length) { var e = seen[dup[0]]; throw new Error('This file was already uploaded (' + e.unit + ', ' + e.date.split('-').reverse().join('/') + ' ' + e.at + ', ' + dup.length + ' delivery notes) — not counted again. Manager can delete that upload first.'); }
    }
    var sum = unit + ' ' + total + ' pcs · ' + Object.keys(stores).map(function (s) { return s + ' ' + stores[s]; }).join(', ');
    eAppend_([eMake_(u, 'scan', date, unit, '', sum, { stores: stores, total: total, notes: notes, fileTotal: num_(p.fileTotal) })]);
    log_(u.name, 'scan.upload', sum);
    return modGet_(u, 'scan', unit, date);
  });
}

/* ───────────────────────── Pending / due (Workshop Out) — totals + latest garment list ───────────────────────── */

/** IT of every store → UL.  Non-IT (DC, OM, ME, PS…) → UL, except PC stores (LT, AC, GT) → PC */
function entity_(storeObj, services, itCodes) {
  var list = String(services || '').toUpperCase().split(/[,\/+ ]+/).map(str_).filter(String);
  if (list.some(function (s) { return itCodes.indexOf(s) >= 0; })) return 'UL';
  return storeObj && storeObj.pc ? 'PC' : 'UL';
}
function latestDue_(date) { var l = eRange_(date, date, 'due', 'ALL'); return l.length ? l[l.length - 1] : null; }
function dueUpload_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date), items = p.items || [];
  if (!items.length) throw new Error('No garments found in the file');
  var smap = storeMap_(), it = settings_().itCodes.map(function (x) { return String(x).toUpperCase(); });
  var byDate = {}, byStore = {}, t = { total: 0, UL: 0, PC: 0, od: 0, odUL: 0, odPC: 0 }, list = [];
  items.forEach(function (x) {
    var raw = str_(x.store).toUpperCase(), so = smap[raw], store = so ? so.code : raw, ent = entity_(so, x.service, it), due = str_(x.due);
    t.total++; t[ent]++;
    var b = byDate[due] = byDate[due] || { UL: 0, PC: 0 }; b[ent]++;
    var s = byStore[store] = byStore[store] || { UL: 0, PC: 0, od: 0 }; s[ent]++;
    if (due && due < date) { t.od++; t[ent === 'UL' ? 'odUL' : 'odPC']++; s.od++; }
    list.push([tx_(due), tx_(str_(x.barcode)), store, str_(x.garment), str_(x.service), ent]);
  });
  list.sort(function (a, b) { return a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0; });
  return withLock_(function () {
    var data = { total: t.total, UL: t.UL, PC: t.PC, od: t.od, odUL: t.odUL, odPC: t.odPC, byDate: byDate, byStore: byStore, time: hmNow_() };
    eAppend_([eMake_(u, 'due', date, 'ALL', '', 'Due ' + t.total + ' (UL ' + t.UL + ' · PC ' + t.PC + ') · overdue ' + t.od, data)]);
    if (date === today_()) {
      clearDueList_();
      if (list.length) sh_(SH.DUELIST).getRange(2, 1, list.length, 6).setValues(list);
    }
    log_(u.name, 'due.upload', t.total + ' pcs');
    return modGet_(u, 'scan', unit, date);
  });
}
function clearDueList_() { var sh = sh_(SH.DUELIST), last = sh.getLastRow(); if (last >= 2) sh.getRange(2, 1, last - 1, 6).clearContent(); }
function dueList_() {
  var sh = sh_(SH.DUELIST), last = sh.getLastRow();
  if (last < 2) return [];
  return sh.getRange(2, 1, last - 1, 6).getValues().filter(function (r) { return str_(r[1]); })
    .map(function (r) { return [dkey_(r[0]), str_(r[1]), str_(r[2]), str_(r[3]), str_(r[4]), str_(r[5])]; });
}

/* ───────────────────────── Daily report (per unit) ───────────────────────── */

function dailyRow_(date, unit) {
  var r = findRows_(sh_(SH.DAILY), 1, date + '|' + unit)[0];
  if (!r) return null;
  return { row: r.row, data: jparse_(r.values[3], {}), filled: num_(r.values[4]), total: num_(r.values[5]), submitted: str_(r.values[6]), by: str_(r.values[7]) };
}
function dailyGet_(u, p) {
  var unit = unit_(u, p), date = seeDate_(u, p.date), d = dailyRow_(date, unit), y = dailyRow_(addDays_(date, -1), unit), prev = {};
  if (y) Object.keys(y.data).forEach(function (k) { if (/^d(18|19|22)_/.test(k)) prev[k] = y.data[k]; });
  return { date: date, unit: unit, prev: prev, data: d ? d.data : {}, meta: d ? { filled: d.filled, total: d.total, submitted: d.submitted, by: d.by } : null, autos: autos_(date, unit) };
}
function dailySave_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date), patch = p.patch || {};
  return withLock_(function () { return dailyWrite_(u, date, unit, patch, p); });
}
function dailyWrite_(u, date, unit, patch, p) {
  var sh = sh_(SH.DAILY), cur = dailyRow_(date, unit), data = cur ? cur.data : {};
  if (cur && cur.submitted && !isMgr_(u)) throw new Error('Report already submitted — only Manager can change it');
  Object.keys(patch).forEach(function (k) { if (patch[k] === null || patch[k] === '') delete data[k]; else data[k] = patch[k]; });
  var submitted = p.submit ? (u.name + ' @ ' + hmNow_()) : (cur ? cur.submitted : '');
  var filled = p.total ? num_(p.filled) : (cur ? cur.filled : 0), total = p.total ? num_(p.total) : (cur ? cur.total : 0);
  var row = [tx_(date + '|' + unit), tx_(date), unit, JSON.stringify(data), filled, total, submitted, u.name, tx_(nowStr_())];
  if (cur) sh.getRange(cur.row, 1, 1, row.length).setValues([row]); else sh.appendRow(row);
  if (p.submit) log_(u.name, 'daily.submit', date + ' ' + unit);
  return { submitted: submitted };
}

/** everything the other screens collected today — shown at the top of the daily report and on home */
function autos_(date, unit) {
  var rows = eRange_(date, date, null, unit), by = {};
  rows.forEach(function (e) { (by[e.mod] = by[e.mod] || []).push(e); });
  var g = function (m) { return by[m] || []; }, sum = function (l, f) { return l.reduce(function (t, e) { return t + num_(f(e)); }, 0); };
  var people = {}, done = {};
  g('rp').forEach(function (e) { e.data.names.forEach(function (n) { people[n] = 1; }); var r = done[e.data.round] = done[e.data.round] || {}; (r[e.store] = r[e.store] || {})[e.data.type] = 1; });
  var ironBy = {}; g('iron').forEach(function (e) { ironBy[e.data.karigar] = (ironBy[e.data.karigar] || 0) + num_(e.data.points); });
  var scan = { UL: 0, PC: 0, total: 0, uploads: 0 };
  eRange_(date, date, 'scan', 'ALL').forEach(function (e) { scan[e.unit] = (scan[e.unit] || 0) + num_(e.data.total); scan.total += num_(e.data.total); scan.uploads++; });
  var due = latestDue_(date), rw = rewashState_(unit, date), rwToday = {};
  g('rewash').forEach(function (e) { var k = rwToday[e.data.kind] = rwToday[e.data.kind] || { Given: 0, Received: 0 }; k[e.data.type] += num_(e.data.qty); });
  var openRep = openItems_('repair', unit), sar = openItems_('saree', unit);
  var sarRecv = eRange_(addDays_(date, -APP.WINDOW), date, 'saree', unit).filter(function (e) { return String(e.data.recvAt || '').slice(0, 10) === date; });
  var boil = {}; g('boiler').forEach(function (e) { var b = boil[e.data.boiler] = boil[e.data.boiler] || { mins: 0, on: false, sessions: 0 }; b.sessions++; b.mins += num_(e.data.mins); if (!e.data.stop) b.on = true; });
  var se = {}; g('staffErr').forEach(function (e) { se[e.data.staff] = (se[e.data.staff] || 0) + 1; });
  var grc = g('grc')[0], meter = g('meter')[0];
  return {
    rp: { entries: g('rp').length, people: Object.keys(people), done: done },
    iron: { entries: g('iron').length, points: sum(g('iron'), function (e) { return e.data.points; }), byK: ironBy },
    scan: scan,
    due: due ? due.data : null,
    rewash: { today: rwToday, balance: Object.keys(rw).reduce(function (m, k) { m[k] = rw[k].balance; return m; }, {}) },
    repair: { sentToday: g('repair').length, pending: openRep.length, back: openRep.filter(function (e) { return e.data.status === 'Back'; }).length, oldest: openRep.length ? openRep[0].date : '' },
    spot: { count: g('spot').length, avg: g('spot').length ? Math.round(sum(g('spot'), function (e) { return e.data.pct; }) / g('spot').length) : 0 },
    quickfix: { count: g('quickfix').length, qf: g('quickfix').filter(function (e) { return e.data.kind === 'QF'; }).length, ir: g('quickfix').filter(function (e) { return e.data.kind === 'IR'; }).length },
    washerr: { count: g('washerr').length, points: sum(g('washerr'), function (e) { return e.data.points; }) },
    staffErr: { count: g('staffErr').length, byStaff: se },
    grc: grc ? grc.data : null,
    meter: meter ? meter.data : null,
    boiler: boil,
    wn: (function () {
      var all = eRange_(addDays_(date, -APP.WINDOW), date, 'wn', unit), adj = all.filter(function (e) { return String(e.data.adjAt || '').slice(0, 10) === date && e.data.kind === 'garment'; });
      var pend = all.filter(function (e) { return e.data.status !== 'Adjusted'; });
      return { adjToday: adj.length, adjList: adj.map(function (e) { return e.data.garment + ' → ' + e.data.inv + ' (' + e.data.adjStore + ')'; }), newToday: g('wn').length,
        pendingG: pend.filter(function (e) { return e.data.kind === 'garment'; }).length, pendingT: pend.filter(function (e) { return e.data.kind === 'tag'; }).length };
    })(),
    saree: {
      sentToday: sum(g('saree'), function (e) { return e.data.qty; }), sentTo: g('saree').map(function (e) { return e.data.to + ' ' + e.data.qty; }),
      recvToday: sum(sarRecv, function (e) { return e.data.recvQty; }), diffToday: sarRecv.filter(function (e) { return e.data.diff; }).map(function (e) { return e.data.to + ' ' + (e.data.diff > 0 ? '+' : '') + e.data.diff + ' (' + e.data.reason + ')'; }),
      pending: sum(sar, function (e) { return e.data.qty; }), batches: sar.length, oldest: sar.length ? sar[0].date : ''
    },
    lots: lotsInfo_(date, unit)
  };
}

/* Daily report list-points (challan error, extra sticker / garment, pending GRC, extra material) */
var ROW_ALERTS = { d16_rows: 'challan', d18_rows: 'sticker', d19_rows: 'extra', d22_rows: 'grc' };
function dailyRowAdd_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date), key = str_(p.key);
  if (!/^d\d+_rows$/.test(key)) throw new Error('Bad point');
  var row = p.row || {};
  Object.keys(row).forEach(function (k) { row[k] = str_(row[k]); if (!row[k]) throw new Error('Fill all boxes'); });
  row.addedBy = u.name; row.at = hmNow_();
  var kind = ROW_ALERTS[key];
  if (kind) sendAlert_(u, kind, date, unit, row);
  return withLock_(function () {
    var cur = dailyRow_(date, unit), list = cur && Array.isArray(cur.data[key]) ? cur.data[key] : [];
    if (key === 'd20_rows') { eAppend_([eMake_(u, 'staffErr', date, unit, '', row.by + ' · Packing / release: ' + row.t, { staff: row.by, note: 'Packing / release mistake: ' + row.t, src: 'daily' })]); row.se = 1; }
    list.push(row);
    var patch = {}; patch[key] = list;
    dailyWrite_(u, date, unit, patch, {});
    return { rows: list };
  });
}
function dailyRowDel_(u, p) {
  if (!isMgr_(u)) throw new Error(lockedMsg_());
  var unit = unit_(u, p), date = validDate_(p.date), key = str_(p.key);
  return withLock_(function () {
    var cur = dailyRow_(date, unit); if (!cur) throw new Error('Not found');
    var list = Array.isArray(cur.data[key]) ? cur.data[key] : [];
    list.splice(+p.idx, 1);
    var patch = {}; patch[key] = list; dailyWrite_(u, date, unit, patch, {});
    return { rows: list };
  });
}
var THEME_MAIL = { hollywood: ['#3B4C28', '#F7E7C2', '#D6AA72', '#58723C'], emerald: ['#0B3B2E', '#F4E7C5', '#C8A45A', '#17644E'], navy: ['#14213D', '#F3E3B5', '#B8893B', '#2B4378'], plum: ['#3A1838', '#F6DCCF', '#C08870', '#64305D'], charcoal: ['#1F2224', '#F2D3B8', '#B8743E', '#3B4146'] };
function storeEmail_(code) {
  var so = storeMap_()[str_(code).toUpperCase()];
  return so && so.email ? so.email : '';
}
/** who gets which alert:
 *  challan → Admin + Accounts · sticker / extra garment → Admin + that store · pending GRC → Admin (info) + that store (action) */
function sendAlert_(u, kind, date, unit, row) {
  var al = settings_().alerts || {}, st = str_(row.st), to = [], cc = [];
  if (kind === 'challan') to = [al.admin, al.account];
  else { to = [storeEmail_(st)]; cc = [al.admin]; }
  to = to.filter(String); cc = cc.filter(String);
  if (!to.length && cc.length) { to = cc; cc = []; }
  if (!to.length) { row.mail = 'no email set'; return; }
  var dd = date.split('-').reverse().join('/'), subject, tag, rows, action, color;
  if (kind === 'challan') {
    tag = 'Challan correction'; color = '#A86A12'; subject = 'Challan name correction · ' + row.ch;
    rows = [['Challan number', row.ch], ['Name written (wrong)', row.wrong], ['Correct name', row.right], ['Mistake by', row.by]];
    action = 'Please correct the customer name on this challan in the software.';
  } else if (kind === 'wntag') {
    tag = 'Detached tag'; color = '#8A6A2E'; subject = 'Detached tag · ' + row.tag + ' · ' + st;
    rows = [['Tag / invoice number', row.tag], ['Store', st], ['Garment', row.g || '—']];
    if (row.note) rows.push(['Note', row.note]);
    action = 'This tag has come detached from the garment at the workshop. Please share a picture of the garment so the workshop can find and match it.';
  } else if (kind === 'grc') {
    tag = 'GRC pending'; color = '#B23B2A'; subject = 'GRC pending · ' + st + ' · ' + str_(row.d).split('-').reverse().join('/');
    rows = [['Store', st], ['GRC date', str_(row.d).split('-').reverse().join('/')]];
    action = 'The GRC of this date is still not clear. Store: please clear it today and inform the workshop. (Admin: for information.)';
  } else {
    tag = kind === 'sticker' ? 'Extra sticker · garment missing' : 'Extra garment · sticker missing'; color = '#B23B2A';
    subject = tag + ' · ' + row.inv + ' · ' + st;
    rows = [['Invoice number', row.inv], ['Garment', row.g], ['Store', st]];
    action = 'Please check this invoice for an error in packing and update the workshop.';
  }
  rows.unshift(['Date', dd], ['Unit', unit]);
  rows.push(['Reported by', u.name + ' · ' + row.at]);
  try {
    var th = THEME_MAIL[settings_().theme] || THEME_MAIL.hollywood, o = { to: to.join(','), subject: 'Workshop · ' + subject, name: 'Hollywood Laundry Service',
      body: subject + '\n\n' + rows.map(function (r) { return r[0] + ': ' + r[1]; }).join('\n') + '\n\n' + action, htmlBody: mailHtml_(th, tag, subject, rows, action, color) };
    if (cc.length) o.cc = cc.join(',');
    MailApp.sendEmail(o);
    row.mail = row.at; log_(u.name, 'alert.' + kind, o.to + (o.cc ? ' cc ' + o.cc : ''));
  } catch (e) { row.mail = 'failed'; }
}
function mailHtml_(th, tag, title, rows, action, color) {
  var e = function (x) { return String(x == null ? '' : x).replace(/&/g, '&amp;').replace(/</g, '&lt;'); };
  return '<!doctype html><html><body style="margin:0;padding:0;background:#EEEDE7">' +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#EEEDE7;padding:28px 12px"><tr><td align="center">' +
    '<table role="presentation" width="580" cellpadding="0" cellspacing="0" style="max-width:580px;width:100%;background:#ffffff;border-radius:18px;overflow:hidden;font-family:Helvetica,Arial,sans-serif;color:#1d2522;box-shadow:0 8px 24px rgba(0,0,0,.08)">' +
    '<tr><td style="background:' + th[0] + ';background:linear-gradient(135deg,' + th[0] + ',' + th[3] + ');padding:22px 26px">' +
      '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>' +
      '<td valign="middle"><div style="font:bold 21px Cambria,Georgia,serif;color:' + th[1] + ';letter-spacing:1.5px">HOLLYWOOD LAUNDRY SERVICE</div><div style="font-size:10.5px;letter-spacing:2.5px;color:' + th[1] + ';opacity:.8;text-transform:uppercase;margin-top:4px">Workshop Operational Control</div><div style="height:2px;width:56px;background:' + th[2] + ';margin-top:9px;border-radius:2px"></div></td>' +
      '</tr></table></td></tr>' +
    '<tr><td style="padding:24px 26px 4px"><span style="display:inline-block;background:' + color + ';color:#fff;font-size:11px;font-weight:bold;letter-spacing:1px;text-transform:uppercase;padding:5px 11px;border-radius:999px">' + e(tag) + '</span>' +
      '<div style="font-size:20px;font-weight:bold;color:' + th[0] + ';margin-top:12px;line-height:1.3">' + e(title) + '</div></td></tr>' +
    '<tr><td style="padding:14px 26px 4px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:separate;border-spacing:0;font-size:14.5px;border:1px solid #ECEAE3;border-radius:12px;overflow:hidden">' +
      rows.map(function (r, i) { return '<tr><td style="padding:11px 14px;color:#6b726f;width:42%;background:' + (i % 2 ? '#ffffff' : '#F8F7F3') + ';border-bottom:1px solid #F0EEE8">' + e(r[0]) + '</td><td style="padding:11px 14px;font-weight:bold;background:' + (i % 2 ? '#ffffff' : '#F8F7F3') + ';border-bottom:1px solid #F0EEE8">' + e(r[1] || '—') + '</td></tr>'; }).join('') +
    '</table></td></tr>' +
    '<tr><td style="padding:18px 26px 26px"><div style="background:#FBF5E6;border-left:4px solid ' + th[2] + ';padding:14px 16px;border-radius:8px;font-size:14.5px;line-height:1.5"><b style="color:' + th[0] + '">Action needed</b><br>' + e(action) + '</div></td></tr>' +
    '<tr><td style="padding:14px 26px;background:#F7F6F2;font-size:11.5px;color:#8a908d;border-top:1px solid #ECEAE3">Sent automatically by Hollywood Laundry Service · Workshop Operational Control · please do not reply to this email</td></tr>' +
    '</table></td></tr></table></body></html>';
}

/* ───────────────────────── Lots — washing lots and iron lots are separate.
   One lot of each type is created automatically every day. A lot stays pending until it is 100% cleared.
   Older lots can be added with their date. ───────────────────────── */

var LOT_TYPES = ['Wash', 'Iron'];
function lotRows_(unit) {
  var sh = sh_(SH.LOTS), last = sh.getLastRow();
  if (last < 2) return [];
  return sh.getRange(2, 1, last - 1, 8).getValues().map(function (v, i) {
    return { row: i + 2, key: str_(v[0]), date: dkey_(v[1]), unit: str_(v[2]), type: str_(v[3]), cleared: num_(v[4]), log: jparse_(v[5], []), by: str_(v[6]), at: str_(v[7]) };
  }).filter(function (r) { return r.unit === unit; });
}
function lotName_(r) { var m = r.key.match(/#(\d+)$/); return r.date + (m ? ' #' + m[1] : ''); }
function ensureLots_(unit, upto) {
  var rows = lotRows_(unit), add = [];
  LOT_TYPES.forEach(function (t) {
    var have = {}, last = '';
    rows.forEach(function (r) { if (r.type === t) { have[r.date] = 1; if (r.date > last) last = r.date; } });
    var start = last ? addDays_(last, 1) : upto;
    if (start < addDays_(upto, -14)) start = addDays_(upto, -14);
    for (var d = start; d <= upto; d = addDays_(d, 1)) if (!have[d]) add.push([tx_(unit + '|' + t + '|' + d), tx_(d), unit, t, 0, '[]', '', '']);
  });
  if (add.length) { var sh = sh_(SH.LOTS); sh.getRange(sh.getLastRow() + 1, 1, add.length, 8).setValues(add); rows = lotRows_(unit); }
  return rows;
}
function lotsInfo_(date, unit) {
  var rows = ensureLots_(unit, today_()), out = {};
  LOT_TYPES.forEach(function (t) {
    var l = rows.filter(function (r) { return r.type === t && r.date <= date; }).sort(function (a, b) { return a.key < b.key ? -1 : 1; });
    out[t] = {
      pending: l.filter(function (r) { return r.cleared < 100; }).map(function (r) { return { key: r.key, name: lotName_(r), date: r.date, cleared: r.cleared }; }),
      today: l.filter(function (r) { return r.log.some(function (x) { return x.at.slice(0, 10) === date; }); }).map(function (r) {
        var lg = r.log.filter(function (x) { return x.at.slice(0, 10) === date; }), lastL = lg[lg.length - 1];
        return { key: r.key, name: lotName_(r), cleared: r.cleared, at: lastL.at.slice(11), by: lastL.by };
      })
    };
  });
  return out;
}
function lotUpdate_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date), pct = Math.round(num_(p.pct));
  if (pct < 0 || pct > 100) throw new Error('Enter 0 – 100 %');
  return withLock_(function () {
    var r = ensureLots_(unit, today_()).filter(function (x) { return x.key === p.lot; })[0];
    if (!r) throw new Error('Lot not found');
    pct = pct >= 100 ? 100 : 0;
    if (pct < r.cleared && !isMgr_(u)) throw new Error('Already cleared — only Manager can undo');
    if (pct === r.cleared) throw new Error(pct ? 'Already cleared' : 'Not cleared yet');
    r.log.push({ at: date + ' ' + hmNow_(), by: u.name, pct: pct });
    sh_(SH.LOTS).getRange(r.row, 5, 1, 4).setValues([[pct, JSON.stringify(r.log), u.name, tx_(nowStr_())]]);
    log_(u.name, 'lot.' + (pct ? 'cleared' : 'undo'), r.key);
    return lotsInfo_(date, unit);
  });
}
function lotCreate_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date), ld = validDate_(p.lotDate || date), t = p.type;
  if (LOT_TYPES.indexOf(t) < 0) throw new Error('Choose washing or iron lot');
  if (ld > today_()) throw new Error('Future date not allowed');
  return withLock_(function () {
    var rows = ensureLots_(unit, today_()).filter(function (r) { return r.type === t && r.date === ld; }), n = rows.length;
    var key = unit + '|' + t + '|' + ld + (n ? ' #' + (n + 1) : '');
    sh_(SH.LOTS).appendRow([tx_(key), tx_(ld), unit, t, 0, '[]', u.name, tx_(nowStr_())]);
    log_(u.name, 'lot.create', key);
    return lotsInfo_(date, unit);
  });
}

/* staff can add new names to some lists (karigar, garment, spot type …) */
function listAdd_(u, p) {
  var path = str_(p.list), val = str_(p.value);
  if (STAFF_LISTS.indexOf(path) < 0 && !isMgr_(u)) throw new Error('No access');
  if (!val) throw new Error('Write a name');
  return withLock_(function () {
    CacheService.getScriptCache().remove('settings');
    var s = settings_(), o = s, parts = path.split('.');
    for (var i = 0; i < parts.length - 1; i++) o = o[parts[i]] = o[parts[i]] || {};
    var k = parts[parts.length - 1]; o[k] = o[k] || [];
    if (!o[k].some(function (x) { return String(x).toLowerCase() === val.toLowerCase(); })) { o[k].push(val); writeSettings_(s); log_(u.name, 'list.add', path + ' ' + val); }
    return { settings: settings_(), value: val };
  });
}

/* ───────────────────────── Home ───────────────────────── */

function home_(u, unit) {
  var date = today_(), d = dailyRow_(date, unit);
  return { date: date, unit: unit, autos: autos_(date, unit), daily: d ? { filled: d.filled, total: d.total, submitted: d.submitted } : null };
}

/* ───────────────────────── Reports ───────────────────────── */

function report_(u, p) {
  var from = validDate_(p.from), to = validDate_(p.to), k = p.kind, unit = unit_(u, p, true);
  if (to < from) throw new Error('Bad period');
  var out = { kind: k, from: from, to: to, unit: unit };
  if (k === 'daily') {
    var units = unit === 'ALL' ? unitsFor_(u) : [unit];
    out.days = units.map(function (un) { var d = dailyRow_(from, un); return { unit: un, data: d ? d.data : {}, meta: d ? { submitted: d.submitted, by: d.by, filled: d.filled, total: d.total } : null, autos: autos_(from, un) }; });
    return out;
  }
  if (k === 'checklist') {
    out.rows = eRange_(from, to, null, unit).map(function (e) { return { mod: e.mod, date: e.date, unit: e.unit }; });
    out.daily = rowsInRange_(sh_(SH.DAILY), 2, from, to).map(function (v) { return { date: dkey_(v[1]), unit: str_(v[2]), filled: num_(v[4]), total: num_(v[5]), submitted: str_(v[6]) }; })
      .filter(function (r) { return unit === 'ALL' || r.unit === unit; });
    return out;
  }
  if (k === 'lots') {
    var us = unit === 'ALL' ? unitsFor_(u) : [unit];
    out.rows = [];
    us.forEach(function (un) { ensureLots_(un, today_()).forEach(function (r) {
      var touched = r.log.some(function (l) { return l.at.slice(0, 10) >= from && l.at.slice(0, 10) <= to; });
      if ((r.date >= from && r.date <= to) || touched || (r.date < from && r.cleared < 100)) { delete r.row; out.rows.push(r); } }); });
    return out;
  }
  if (k === 'scan') { out.rows = eRange_(from, to, ['scan', 'due'], 'ALL').filter(function (e) { return unit === 'ALL' || e.mod === 'due' || e.unit === unit; }); return out; }
  if (k === 'daily-sum') { out.rows = rowsInRange_(sh_(SH.DAILY), 2, from, to).map(function (v) { return { date: dkey_(v[1]), unit: str_(v[2]), data: jparse_(v[3], {}), submitted: str_(v[6]) }; }); return out; }
  out.rows = eRange_(from, to, k, unit);
  if (k === 'rewash') {
    var us2 = unit === 'ALL' ? unitsFor_(u) : [unit], open = {};
    us2.forEach(function (un) { var st = rewashState_(un, addDays_(from, -1)); Object.keys(st).forEach(function (x) { open[x] = (open[x] || 0) + st[x].balance; }); });
    out.opening = open;
  }
  if (k === 'repair' || k === 'saree' || k === 'wn') {
    var seen = {}; out.rows.forEach(function (e) { seen[e.id] = 1; });
    openItems_(k, unit).forEach(function (e) { if (!seen[e.id] && e.date < from) out.rows.unshift(e); });
  }
  if (k === 'meter') out.last = unit === 'ALL' ? {} : meterLast_(unit, from);
  return out;
}

/* ───────────────────────── Settings & Users ───────────────────────── */

function settingsSave_(u, p) {
  var s = p.settings;
  if (!s || !s.stores || !s.teams || !s.units || !s.units.length) throw new Error('Bad settings');
  s.units = s.units.map(function (x) { return str_(x).toUpperCase(); }).filter(String);
  s.stores = s.stores.filter(function (x) { return str_(x.code); }).map(function (x) {
    return { code: str_(x.code).toUpperCase(), aliases: (x.aliases || []).map(function (a) { return str_(a).toUpperCase(); }).filter(String), pc: !!x.pc, email: str_(x.email) };
  });
  s.boilers = (s.boilers || []).filter(function (b) { return str_(b.name); }).map(function (b) { return { name: str_(b.name), unit: s.units.indexOf(b.unit) >= 0 ? b.unit : s.units[0], staff: (b.staff || []).map(str_).filter(String) }; });
  s.meters = (s.meters || []).filter(function (m) { return str_(m.name); }).map(function (m) { return { name: str_(m.name), measure: str_(m.measure) }; });
  withLock_(function () { writeSettings_(s); });
  log_(u.name, 'settings.save', '');
  return settings_();
}
function usersList_() { return users_().map(function (u) { return { name: u.name, role: u.role, modules: u.modules, active: u.active, units: u.units }; }); }
function usersSave_(u, p) {
  var old = {}, seen = {}; users_().forEach(function (x) { old[x.name.toLowerCase()] = x; });
  var rows = (p.users || []).filter(function (x) { return str_(x.name); }).map(function (x) {
    var key = str_(x.name).toLowerCase();
    if (seen[key]) throw new Error('Name used twice: ' + x.name); seen[key] = 1;
    var prev = old[key] || {}, pin = x.pin ? str_(x.pin) : (prev.pin || '');
    if (!/^\d{4}$/.test(pin)) throw new Error('PIN must be 4 digits for ' + x.name);
    var role = ['Admin', 'Manager', 'Staff'].indexOf(x.role) >= 0 ? x.role : 'Staff';
    return [str_(x.name), role, tx_(pin), (x.modules || []).join(','), x.active !== false, (x.units || []).join(',')];
  });
  if (!rows.some(function (r) { return r[1] === 'Admin' && r[4]; })) throw new Error('Keep at least one active Admin');
  withLock_(function () {
    var sh = sh_(SH.USERS), last = sh.getLastRow();
    if (last >= 2) sh.getRange(2, 1, last - 1, 6).clearContent();
    if (rows.length) sh.getRange(2, 1, rows.length, 6).setValues(rows);
    CacheService.getScriptCache().remove('users');
  });
  log_(u.name, 'users.save', rows.length + ' users');
  return usersList_();
}

/* ───────────────────────── WN (without number) — garment whose tag is missing, and tags found without garment ─────────────────────────
   Garment: photo + garment + ironman → stays pending until adjusted with an invoice number and store.
   Detached tag: tag no. + store → stays pending. Adjusting a garment with the same invoice closes the tag too. */

function wnAdjust_(u, p) {
  var unit = unit_(u, p), date = dateFor_(u, p.date), inv = str_(p.inv).toUpperCase(), store = str_(p.store);
  return withLock_(function () {
    var f = eFind_(p.id), d = f.e.data;
    if (f.e.mod !== 'wn' || f.e.unit !== unit) throw new Error('Not found');
    if (d.status === 'Adjusted') throw new Error('Already adjusted');
    if (d.kind === 'garment') { if (!inv) throw new Error('Enter the invoice number'); if (!store) throw new Error('Choose the store'); }
    else { inv = d.tag; store = store || f.e.store; }
    d.status = 'Adjusted'; d.inv = inv; d.adjStore = store; d.adjAt = date + ' ' + hmNow_(); d.adjBy = u.name; if (p.note) d.adjNote = str_(p.note);
    f.e.summary = (d.kind === 'tag' ? 'Detached tag ' + d.tag : 'WN ' + d.garment) + ' · adjusted ' + inv + ' (' + store + ')';
    var linked = '';
    if (d.kind === 'garment') {   // close a matching detached tag
      var t = openItems_('wn', unit).filter(function (e) { return e.data.kind === 'tag' && e.data.tag === inv; })[0];
      if (t) {
        var tf = eFind_(t.id); tf.e.data.status = 'Adjusted'; tf.e.data.inv = inv; tf.e.data.adjStore = store; tf.e.data.adjAt = d.adjAt; tf.e.data.adjBy = u.name; tf.e.data.link = f.e.id;
        tf.e.summary = 'Detached tag ' + inv + ' · matched with WN ' + d.garment; eWrite_(tf.row, tf.e); d.link = t.id; linked = t.id;
      }
    }
    eWrite_(f.row, f.e); log_(u.name, 'wn.adjust', f.e.id + ' ' + inv);
    var out = modGet_(u, 'wn', unit, date); out.linked = linked; return out;
  });
}

/* Photos — saved in Drive (Workshop WN Photos / yyyy-mm), visible to anyone with the link so the app can show them */
function photo_(u, p) {
  if (!p.data) throw new Error('No photo');
  var it = DriveApp.getFoldersByName(APP.PHOTO_FOLDER), root = it.hasNext() ? it.next() : DriveApp.createFolder(APP.PHOTO_FOLDER);
  var mon = today_().slice(0, 7), mi = root.getFoldersByName(mon), folder = mi.hasNext() ? mi.next() : root.createFolder(mon);
  var f = folder.createFile(Utilities.newBlob(Utilities.base64Decode(p.data), 'image/jpeg', today_() + '_' + (str_(p.name) || 'wn') + '_' + uid_() + '.jpg'));
  try { f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) { }
  return { id: f.getId(), url: f.getUrl() };
}

/* ───────────────────────── Backup & move to a new file ─────────────────────────
   Export (old file): masters (settings, users) + everything still pending:
     open repairs, sarees at polish, WN garments / tags, rewash still pending (by date), pending lots, last meter readings.
   Import (new file, after setup): writes them in. Completed history stays in the old file. */

var BACKUP_VERSION = 1;
function backupStats_() {
  var n = function (name) { var sh = sh_(name); return sh ? Math.max(0, sh.getLastRow() - 1) : 0; };
  var cells = 0; ss_().getSheets().forEach(function (sh) { cells += sh.getMaxRows() * sh.getMaxColumns(); });
  return { entries: n(SH.ENT), daily: n(SH.DAILY), lots: n(SH.LOTS), log: n(SH.LOG), users: n(SH.USERS), cells: cells, limit: 10000000 };
}
function backupExport_(u) {
  var t = today_(), units = settings_().units || ['UL'], entries = [];
  var raw = function (e) { return [e.id, e.mod, e.date, e.unit, e.store, e.summary, JSON.stringify(e.data), e.by, e.stamp]; };
  ['repair', 'saree', 'wn'].forEach(function (m) { openItems_(m, 'ALL').forEach(function (e) { entries.push(raw(e)); }); });
  units.forEach(function (un) {
    var st = rewashState_(un, t);
    Object.keys(st).forEach(function (k) { st[k].pending.forEach(function (x) {
      entries.push([uid_(), 'rewash', x.date, un, '', k + ' · Given · ' + x.left + ' pcs · carried forward', JSON.stringify({ kind: k, type: 'Given', qty: x.left, by: 'carried' }), u.name, x.date + ' 00:00:00']);
    }); });
    var ml = meterLast_(un, addDays_(t, 1)), rd = {};
    Object.keys(ml).forEach(function (m) { rd[m] = ml[m].reading; });
    if (Object.keys(rd).length) { var md = Object.keys(ml).map(function (m) { return ml[m].date; }).sort().pop();
      entries.push([uid_(), 'meter', md, un, '', 'Last readings carried forward', JSON.stringify({ readings: rd, used: {} }), u.name, md + ' 00:00:00']); }
  });
  var lots = [];
  units.forEach(function (un) { ensureLots_(un, t).forEach(function (r) { if (r.cleared < 100) lots.push([r.key, r.date, r.unit, r.type, r.cleared, JSON.stringify(r.log), r.by, r.at]); }); });
  var users = sh_(SH.USERS).getRange(2, 1, Math.max(1, sh_(SH.USERS).getLastRow() - 1), 6).getValues().filter(function (r) { return str_(r[0]); }).map(function (r) { return r.map(function (c) { return c === true || c === false ? c : str_(c); }); });
  var data = { app: 'Workshop Operational Control', version: BACKUP_VERSION, exportedAt: nowStr_(), exportedBy: u.name, settings: settings_(), users: users, entries: entries, lots: lots,
    counts: { entries: entries.length, lots: lots.length, users: users.length } };
  var url = '';
  try {
    var it = DriveApp.getFoldersByName(APP.BACKUP_FOLDER), folder = it.hasNext() ? it.next() : DriveApp.createFolder(APP.BACKUP_FOLDER);
    url = folder.createFile('workshop-backup-' + t + '.json', JSON.stringify(data), 'application/json').getUrl();
  } catch (e) { }
  log_(u.name, 'backup.export', entries.length + ' entries, ' + lots.length + ' lots');
  return { data: data, url: url };
}
function backupImport_(u, p) {
  var d = p.data;
  if (!d || d.app !== 'Workshop Operational Control' || !d.settings || !Array.isArray(d.users)) throw new Error('This is not a Workshop backup file');
  if (num_(d.version) > BACKUP_VERSION) throw new Error('Backup is from a newer version of the app');
  return withLock_(function () {
    writeSettings_(d.settings);
    var users = d.users.filter(function (r) { return str_(r[0]); }).map(function (r) { return [str_(r[0]), str_(r[1]) || 'Staff', tx_(str_(r[2])), str_(r[3]), !(r[4] === false || String(r[4]).toUpperCase() === 'FALSE'), str_(r[5])]; });
    if (!users.some(function (r) { return r[1] === 'Admin' && r[4]; })) throw new Error('Backup has no active Admin');
    var us = sh_(SH.USERS), last = us.getLastRow();
    if (last >= 2) us.getRange(2, 1, last - 1, 6).clearContent();
    us.getRange(2, 1, users.length, 6).setValues(users);
    var have = {}, esh = sh_(SH.ENT);
    if (esh.getLastRow() >= 2) esh.getRange(2, 1, esh.getLastRow() - 1, 1).getValues().forEach(function (r) { have[str_(r[0])] = 1; });
    var rows = (d.entries || []).filter(function (r) { return r && r[0] && !have[r[0]]; }).map(function (r) { return [r[0], r[1], tx_(r[2]), r[3], str_(r[4]), str_(r[5]), str_(r[6]), str_(r[7]), tx_(r[8])]; });
    rows.sort(function (a, b) { return a[2] < b[2] ? -1 : a[2] > b[2] ? 1 : 0; });
    eAppend_(rows);
    var lsh = sh_(SH.LOTS), lhave = {};
    if (lsh.getLastRow() >= 2) lsh.getRange(2, 1, lsh.getLastRow() - 1, 1).getValues().forEach(function (r) { lhave[str_(r[0])] = 1; });
    var lots = (d.lots || []).filter(function (r) { return r && r[0] && !lhave[r[0]]; }).map(function (r) { return [tx_(r[0]), tx_(r[1]), r[2], r[3], num_(r[4]), str_(r[5]) || '[]', str_(r[6]), tx_(str_(r[7]))]; });
    if (lots.length) lsh.getRange(lsh.getLastRow() + 1, 1, lots.length, 8).setValues(lots);
    var dn = 0;
    if (Array.isArray(d.daily) && d.daily.length) {
      var dsh = sh_(SH.DAILY), dhave = {};
      if (dsh.getLastRow() >= 2) dsh.getRange(2, 1, dsh.getLastRow() - 1, 1).getValues().forEach(function (r) { dhave[str_(r[0])] = 1; });
      var drows = d.daily.filter(function (r) { return r && r[0] && !dhave[r[0]]; }).map(function (r) { return [tx_(r[0]), tx_(r[1]), r[2], str_(r[3]), num_(r[4]), num_(r[5]), str_(r[6]), str_(r[7]), tx_(str_(r[8]))]; });
      if (drows.length) dsh.getRange(dsh.getLastRow() + 1, 1, drows.length, 9).setValues(drows);
      dn = drows.length;
    }
    CacheService.getScriptCache().removeAll(['users', 'settings']);
    log_(u.name, 'backup.import', rows.length + ' entries, ' + lots.length + ' lots, ' + users.length + ' users from ' + d.exportedAt);
    return { entries: rows.length, lots: lots.length, users: users.length, daily: dn, settings: settings_() };
  });
}

/** FULL export (all history) — used when moving from Google Sheets to the AWS server.
 *  Contains everything: settings, users, all entries, all daily reports, all lots. */
function backupExportAll_(u) {
  var grab = function (name, w) { var sh = sh_(name), last = sh.getLastRow(); return last < 2 ? [] : sh.getRange(2, 1, last - 1, w).getValues().map(function (r) { return r.map(function (c) { return c instanceof Date ? Utilities.formatDate(c, APP.TZ, 'yyyy-MM-dd HH:mm:ss') : c; }); }); };
  var entries = grab(SH.ENT, 9).filter(function (r) { return str_(r[0]); }).map(function (r) { return [str_(r[0]), str_(r[1]), dkey_(r[2]), str_(r[3]), str_(r[4]), str_(r[5]), str_(r[6]), str_(r[7]), str_(r[8])]; });
  var daily = grab(SH.DAILY, 9).filter(function (r) { return str_(r[0]); }).map(function (r) { return r.map(function (c) { return typeof c === 'number' ? c : str_(c); }); });
  var lots = grab(SH.LOTS, 8).filter(function (r) { return str_(r[0]); }).map(function (r) { return r.map(function (c) { return typeof c === 'number' ? c : str_(c); }); });
  var users = grab(SH.USERS, 6).filter(function (r) { return str_(r[0]); }).map(function (r) { return r.map(function (c) { return c === true || c === false ? c : str_(c); }); });
  var data = { app: 'Workshop Operational Control', version: BACKUP_VERSION, full: true, exportedAt: nowStr_(), exportedBy: u.name, settings: settings_(), users: users, entries: entries, lots: lots, daily: daily,
    counts: { entries: entries.length, lots: lots.length, users: users.length, daily: daily.length } };
  var url = '';
  try {
    var it = DriveApp.getFoldersByName(APP.BACKUP_FOLDER), folder = it.hasNext() ? it.next() : DriveApp.createFolder(APP.BACKUP_FOLDER);
    url = folder.createFile('workshop-FULL-' + today_() + '.json', JSON.stringify(data), 'application/json').getUrl();
  } catch (e) { }
  log_(u.name, 'backup.exportAll', entries.length + ' entries');
  return { data: data, url: url };
}
