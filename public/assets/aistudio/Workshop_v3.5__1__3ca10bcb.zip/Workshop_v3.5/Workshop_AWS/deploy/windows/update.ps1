﻿# Install a newer version on the Windows server — data and settings are NOT touched.
# Start it with  update.bat  (right-click ▶ Run as administrator)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$App  = 'C:\Workshop'
Stop-ScheduledTask -TaskName 'Workshop App' -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
$keepEnv = Get-Content "$App\server\.env" -Raw
Remove-Item -Recurse -Force "$App\public"
Copy-Item -Path "$Root\public" -Destination $App -Recurse -Force
foreach ($f in 'server.js', 'Code.gs', 'package.json', '.env.example') { Copy-Item "$Root\server\$f" "$App\server\$f" -Force }
Set-Content -Path "$App\server\.env" -Value $keepEnv -NoNewline
Push-Location "$App\server"; & 'C:\Program Files\nodejs\npm.cmd' install --omit=dev --no-audit --no-fund; Pop-Location
Start-ScheduledTask -TaskName 'Workshop App'
Start-Sleep -Seconds 5
Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:8080/healthz' -TimeoutSec 10 | Out-Null
Write-Host 'OK - updated and running.' -ForegroundColor Green
