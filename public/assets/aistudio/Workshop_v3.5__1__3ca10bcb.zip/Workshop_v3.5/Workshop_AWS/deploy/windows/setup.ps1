﻿# Workshop Operational Control — install on a Windows server (runs next to Tally)
# Start it with  setup.bat  (right-click ▶ Run as administrator)
param([string]$Domain, [string]$Email)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue'

$Root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)      # the unzipped Workshop_AWS folder
$App  = 'C:\Workshop'
$Data = 'C:\Workshop\data'
$Node = 'C:\Program Files\nodejs\node.exe'
$Npm  = 'C:\Program Files\nodejs\npm.cmd'

if (-not $Domain) { $Domain = Read-Host 'Web address for the app (example: workshop.yourcompany.com)' }
if (-not $Email)  { $Email  = Read-Host 'Your email (for the HTTPS certificate)' }
if (-not $Domain -or -not $Email) { throw 'Web address and email are needed.' }

Write-Host '== 1/6  Node.js' -ForegroundColor Cyan
if (-not (Test-Path $Node)) {
  $msi = Join-Path $env:TEMP 'node-v20.18.1-x64.msi'
  Invoke-WebRequest -UseBasicParsing 'https://nodejs.org/dist/v20.18.1/node-v20.18.1-x64.msi' -OutFile $msi
  Start-Process msiexec.exe -Wait -ArgumentList "/i `"$msi`" /qn /norestart"
}
if (-not (Test-Path $Node)) { throw 'Node.js did not install.' }

Write-Host '== 2/6  App files' -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $App, $Data | Out-Null
$keepEnv = $null
if (Test-Path "$App\server\.env") { $keepEnv = Get-Content "$App\server\.env" -Raw }
Copy-Item -Path "$Root\server", "$Root\public" -Destination $App -Recurse -Force
if ($keepEnv) { Set-Content -Path "$App\server\.env" -Value $keepEnv -NoNewline }
else {
  $envText = Get-Content "$App\server\.env.example" -Raw
  $envText = $envText -replace '(?m)^DATA_DIR=.*$', "DATA_DIR=$Data"
  $envText += "`r`n# This server switches off at about 8:10 pm, so the daily backup runs before that`r`nBACKUP_AT=19:45`r`n"
  Set-Content -Path "$App\server\.env" -Value $envText
}
Push-Location "$App\server"
& $Npm install --omit=dev --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { Pop-Location; throw 'npm install failed.' }
Pop-Location

Write-Host '== 3/6  Caddy (gives the app its https:// certificate)' -ForegroundColor Cyan
if (-not (Test-Path "$App\caddy.exe")) {
  Invoke-WebRequest -UseBasicParsing 'https://caddyserver.com/api/download?os=windows&arch=amd64' -OutFile "$App\caddy.exe"
}
$caddyfile = "{`r`n  email $Email`r`n}`r`n$Domain {`r`n  encode gzip`r`n  reverse_proxy 127.0.0.1:8080`r`n}`r`n"
Set-Content -Path "$App\Caddyfile" -Value $caddyfile -Encoding ASCII

Write-Host '== 4/6  Windows firewall: allow web ports 80 and 443' -ForegroundColor Cyan
foreach ($port in 80, 443) {
  $name = "Workshop web $port"
  if (-not (Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName $name -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow | Out-Null
  }
}

Write-Host '== 5/6  Start automatically every time the server switches on' -ForegroundColor Cyan
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$trigger  = New-ScheduledTaskTrigger -AtStartup
$appAct   = New-ScheduledTaskAction -Execute $Node -Argument 'server.js' -WorkingDirectory "$App\server"
$cadAct   = New-ScheduledTaskAction -Execute "$App\caddy.exe" -Argument "run --config `"$App\Caddyfile`" --adapter caddyfile" -WorkingDirectory $App
Register-ScheduledTask -TaskName 'Workshop App'   -Action $appAct -Trigger $trigger -Settings $settings -User 'SYSTEM' -RunLevel Highest -Force | Out-Null
Register-ScheduledTask -TaskName 'Workshop HTTPS' -Action $cadAct -Trigger $trigger -Settings $settings -User 'SYSTEM' -RunLevel Highest -Force | Out-Null
Stop-ScheduledTask -TaskName 'Workshop App'   -ErrorAction SilentlyContinue
Stop-ScheduledTask -TaskName 'Workshop HTTPS' -ErrorAction SilentlyContinue
Start-ScheduledTask -TaskName 'Workshop App'
Start-ScheduledTask -TaskName 'Workshop HTTPS'

Write-Host '== 6/6  Check' -ForegroundColor Cyan
Start-Sleep -Seconds 6
try {
  $r = Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:8080/healthz' -TimeoutSec 10
  Write-Host ''
  Write-Host "OK - the app is running.  Open  https://$Domain   (first login: Admin / 1234)" -ForegroundColor Green
  Write-Host 'If https does not open yet: check the DNS record and the AWS security group (ports 80 and 443).' -ForegroundColor Yellow
} catch {
  Write-Host 'The app did not answer. Open Task Scheduler ▶ "Workshop App" ▶ History, or run:' -ForegroundColor Red
  Write-Host "  cd $App\server ; & '$Node' server.js" -ForegroundColor Red
}
