'use strict';
/**
 * Workshop Operational Control — AWS server
 * ------------------------------------------------------------
 * Runs the SAME business logic as the Google version (Code.gs) inside Node.js.
 * The Google services Code.gs uses (Sheets, Drive, Mail, Cache, Properties…) are replaced
 * by small local versions here: data goes into one SQLite database file, photos into a folder,
 * emails go out through SMTP (Amazon SES or any mail account).
 *
 *   data/workshop.db      ← all data (one file — back it up)
 *   data/photos/          ← WN photos
 *   data/backups/         ← nightly copies of the database (last 30 days)
 *
 * Settings come from the file  .env  next to this file (see .env.example).
 */
const fs = require('fs'), path = require('path'), http = require('http'), vm = require('vm'), crypto = require('crypto');
const Database = require('better-sqlite3');

/* ───────── config ───────── */
const ROOT = __dirname;
loadEnv(path.join(ROOT, '.env'));
const DATA = process.env.DATA_DIR || path.join(ROOT, 'data');
const PUBLIC = process.env.PUBLIC_DIR || path.join(ROOT, '..', 'public');
const CODE = process.env.CODE_FILE || path.join(ROOT, 'Code.gs');
const PORT = +process.env.PORT || 8080;
const TZ = 'Asia/Kolkata';
['', 'photos', 'backups'].forEach(function (d) { fs.mkdirSync(path.join(DATA, d), { recursive: true }); });

function loadEnv(f) {
  if (!fs.existsSync(f)) return;
  fs.readFileSync(f, 'utf8').split(/\r?\n/).forEach(function (l) {
    var m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/); if (!m || process.env[m[1]] !== undefined) return;
    process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  });
}

/* ───────── database: one table per "sheet", same column order as the Google sheets ───────── */
const db = new Database(path.join(DATA, 'workshop.db'));
db.pragma('journal_mode = WAL'); db.pragma('synchronous = NORMAL'); db.pragma('busy_timeout = 5000');

const TABLES = {
  Users:    { cols: 6, key: 0 },             // Name, Role, PIN, Modules, Active, Units
  Settings: { cols: 2, key: 0 },             // Key, Value
  Daily:    { cols: 9, key: 0, date: 1 },    // Key, Date, Unit, Data, Filled, Total, Submitted, UpdatedBy, UpdatedAt
  Entries:  { cols: 9, key: 0, date: 2 },    // ID, Module, Date, Unit, Store, Summary, Data, By, At
  Lots:     { cols: 8, key: 0 },             // Key, Date, Unit, Type, Cleared, Log, UpdatedBy, UpdatedAt
  DueList:  { cols: 6 },                     // Due, Barcode, Store, Garment, Service, Unit
  Log:      { cols: 4 }                      // At, User, Action, Detail
};
Object.keys(TABLES).forEach(function (t) {
  var T = TABLES[t], cols = [];
  for (var i = 1; i <= T.cols; i++) cols.push('c' + i + (T.key === i - 1 ? ' UNIQUE' : ''));   // no type → values keep their type
  db.exec('CREATE TABLE IF NOT EXISTS "' + t + '" (rid INTEGER PRIMARY KEY AUTOINCREMENT, ' + cols.join(', ') + ')');
  if (T.date !== undefined) db.exec('CREATE INDEX IF NOT EXISTS "ix_' + t + '_date" ON "' + t + '"(c' + (T.date + 1) + ')');
});
db.exec('CREATE INDEX IF NOT EXISTS ix_Entries_mod ON Entries(c2, c3)');
db.exec('CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v)');

function clean(v) {   // value going INTO the database (Sheets-style "'text" → text, true/false → TRUE/FALSE)
  if (v === undefined || v === null) return '';
  if (typeof v === 'string' && v.charAt(0) === "'") return v.slice(1);
  if (v === true) return 'TRUE'; if (v === false) return 'FALSE';
  if (v instanceof Date) return v.toISOString();
  if (typeof v === 'object') return JSON.stringify(v);
  return v;
}
function out(v) { return v === null || v === undefined ? '' : v; }

/** A "sheet" backed by a table — supports exactly what Code.gs uses. Row 1 is the header. */
function Sheet(name) {
  var T = TABLES[name], n = T.cols, cols = []; for (var i = 1; i <= n; i++) cols.push('c' + i);
  var sel = 'SELECT ' + cols.join(',') + ' FROM "' + name + '"', ord = ' ORDER BY rid';
  var ins = db.prepare('INSERT INTO "' + name + '" (' + cols.join(',') + ') VALUES (' + cols.map(function () { return '?'; }).join(',') + ')');
  var ups = T.key !== undefined ? db.prepare('INSERT INTO "' + name + '" (' + cols.join(',') + ') VALUES (' + cols.map(function () { return '?'; }).join(',') + ') ON CONFLICT(c' + (T.key + 1) + ') DO UPDATE SET ' + cols.filter(function (c, i) { return i !== T.key; }).map(function (c) { return c + '=excluded.' + c; }).join(',')) : ins;
  var arr = function (r) { return cols.map(function (c) { return out(r[c]); }); };
  var write = function (row) { var v = []; for (var i = 0; i < n; i++) v.push(clean(row[i])); ups.run(v); };
  var keyWhere = function (r) {   // a row is addressed by its key (string) or by its position (number)
    if (typeof r === 'string') return { w: 'c' + (T.key + 1) + '=?', a: [r] };
    var rid = db.prepare('SELECT rid FROM "' + name + '"' + ord + ' LIMIT 1 OFFSET ?').get(r - 2);
    return { w: 'rid=?', a: [rid ? rid.rid : -1] };
  };
  var self = {
    name: name,
    getName: function () { return name; },
    getLastRow: function () { return db.prepare('SELECT COUNT(*) n FROM "' + name + '"').get().n + 1; },
    getLastColumn: function () { return n; },
    getMaxRows: function () { return self.getLastRow(); }, getMaxColumns: function () { return n; },
    appendRow: function (row) { write(row); },
    deleteRow: function (r) { var k = keyWhere(r); db.prepare('DELETE FROM "' + name + '" WHERE ' + k.w).run(k.a); },
    find: function (col, key) {
      return db.prepare(sel + ' WHERE c' + col + '=?' + ord).all(String(key)).map(function (r) { var a = arr(r); return { row: T.key !== undefined ? String(a[T.key]) : 0, values: a }; });
    },
    range: function (col, from, to) { return db.prepare(sel + ' WHERE c' + col + ' >= ? AND c' + col + ' <= ?' + ord).all(from, to).map(arr); },
    getRange: function (r, c, nr, nc) {
      nr = nr || 1; nc = nc || 1;
      return {
        getValues: function () {
          var rows = typeof r === 'string' ? self.find(T.key + 1, r).map(function (x) { return x.values; }) : db.prepare(sel + ord + ' LIMIT ? OFFSET ?').all(nr, r - 2).map(arr);
          return rows.map(function (a) { return a.slice(c - 1, c - 1 + nc); });
        },
        setValues: function (vals) {
          if (c === 1 && nc === n) {   // whole rows → insert / update by key
            vals.forEach(function (row) { if (T.key === undefined || typeof r === 'number' || String(clean(row[T.key])) === String(r)) write(row); else write(row); });
            return this;
          }
          var k = keyWhere(r), set = []; for (var j = 0; j < nc; j++) set.push('c' + (c + j) + '=?');   // part of one row
          db.prepare('UPDATE "' + name + '" SET ' + set.join(',') + ' WHERE ' + k.w).run(vals[0].map(clean).concat(k.a));
          return this;
        },
        setValue: function (v) { return this.setValues([[v]]); },
        clearContent: function () { if (r === 2) db.prepare('DELETE FROM "' + name + '"').run(); else self.deleteRow(r); return this; },
        createTextFinder: function (key) { return { matchEntireCell: function () { return this; }, findAll: function () { return self.find(c, key).map(function (x) { return { getRow: function () { return x.row; } }; }); } }; },
        setFontWeight: function () { return this; }, setBackground: function () { return this; }, setFontColor: function () { return this; }
      };
    },
    setFrozenRows: function () { }, setName: function () { }
  };
  return self;
}
const SHEETS = {}; Object.keys(TABLES).forEach(function (t) { SHEETS[t] = Sheet(t); });

/* ───────── replacements for the Google services ───────── */
const cache = new Map();
const CacheService = { getScriptCache: function () { return {
  get: function (k) { var x = cache.get(k); if (!x) return null; if (x.e < Date.now()) { cache.delete(k); return null; } return x.v; },
  put: function (k, v, s) { cache.set(k, { v: String(v), e: Date.now() + (s || 600) * 1000 }); },
  remove: function (k) { cache.delete(k); }, removeAll: function (l) { l.forEach(function (k) { cache.delete(k); }); }
}; } };
const PropertiesService = { getScriptProperties: function () { return {
  getProperty: function (k) { var r = db.prepare('SELECT v FROM kv WHERE k=?').get(k); return r ? r.v : null; },
  setProperty: function (k, v) { db.prepare('INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, String(v)); }
}; } };
const LockService = { getScriptLock: function () { return { waitLock: function () { }, releaseLock: function () { } }; } };
function fmtDate(d, tz, f) {
  var p = {}; new Intl.DateTimeFormat('en-GB', { timeZone: tz || TZ, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })
    .formatToParts(d).forEach(function (x) { p[x.type] = x.value; });
  if (p.hour === '24') p.hour = '00';
  return f.replace('yyyy', p.year).replace('MM', p.month).replace('dd', p.day).replace('HH', p.hour).replace('mm', p.minute).replace('ss', p.second);
}
const toBuf = function (x) { return Buffer.isBuffer(x) ? x : Array.isArray(x) ? Buffer.from(x) : Buffer.from(String(x), 'utf8'); };
const Utilities = {
  formatDate: fmtDate,
  base64EncodeWebSafe: function (x) { return toBuf(x).toString('base64').replace(/\+/g, '-').replace(/\//g, '_'); },
  base64DecodeWebSafe: function (s) { return Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64'); },
  base64Decode: function (s) { return Buffer.from(String(s), 'base64'); },
  computeHmacSha256Signature: function (p, k) { return crypto.createHmac('sha256', String(k)).update(String(p)).digest(); },
  newBlob: function (x, mime, name) { var b = toBuf(x); return { bytes: b, name: name, mime: mime, getDataAsString: function () { return b.toString('utf8'); } }; },
  getUuid: function () { return crypto.randomUUID(); }
};
/* email — SMTP (Amazon SES SMTP, Gmail app password, Zoho …). Without SMTP settings, emails are only logged. */
let mailer = null;
if (process.env.SMTP_HOST) {
  mailer = require('nodemailer').createTransport({ host: process.env.SMTP_HOST, port: +process.env.SMTP_PORT || 587, secure: +process.env.SMTP_PORT === 465,
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined });
}
const MailApp = { sendEmail: function (o) {
  if (!mailer) { console.log('[mail not configured] would send to', o.to, '·', o.subject); return; }
  mailer.sendMail({ from: (o.name ? '"' + o.name + '" ' : '') + '<' + (process.env.MAIL_FROM || process.env.SMTP_USER) + '>', to: o.to, cc: o.cc, subject: o.subject, text: o.body, html: o.htmlBody })
    .catch(function (e) { console.error('mail failed', o.to, e.message); try { C.log_('system', 'mail.failed', o.to + ' ' + e.message); } catch (x) { } });
} };
/* backups made from Settings are downloaded in the browser; Drive saving is not needed here */
const DriveApp = { Access: {}, Permission: {},
  getFoldersByName: function () { return { hasNext: function () { return false; } }; },
  createFolder: function () { return { createFile: function () { return { getUrl: function () { return ''; }, getId: function () { return ''; }, setSharing: function () { } }; }, getFoldersByName: function () { return { hasNext: function () { return false; } }; }, createFolder: function () { return this; } }; } };

/* ───────── load Code.gs (the same file as the Google version) ───────── */
const C = vm.createContext({
  console: console, Utilities: Utilities, CacheService: CacheService, PropertiesService: PropertiesService, LockService: LockService,
  MailApp: MailApp, DriveApp: DriveApp, Logger: { log: function (x) { console.log(x); } },
  SpreadsheetApp: {}, HtmlService: {}, JSON: JSON, Date: Date, Math: Math, Intl: Intl
});
vm.runInContext(fs.readFileSync(CODE, 'utf8'), C, { filename: 'Code.gs' });

/* data access → database */
C.ss_ = function () { return { getSheets: function () { return Object.keys(SHEETS).map(function (k) { return SHEETS[k]; }); }, getId: function () { return 'sqlite'; } }; };
C.sh_ = function (name) { return SHEETS[name] || null; };
C.findRows_ = function (sheet, col, key) { return sheet.find(col, key); };
C.rowsInRange_ = function (sheet, col, from, to) { return sheet.range(col, from, to); };
C.withLock_ = function (fn) { return db.transaction(fn)(); };   // all-or-nothing: an error undoes the whole save
/* fast search by date + screen (uses the database index instead of reading every row) */
C.eRange_ = function (from, to, mod, unit) {
  var mods = mod ? [].concat(mod) : null, sql = 'SELECT c1,c2,c3,c4,c5,c6,c7,c8,c9 FROM Entries WHERE c3 >= ? AND c3 <= ?', args = [from, to];
  if (mods) { sql += ' AND c2 IN (' + mods.map(function () { return '?'; }).join(',') + ')'; args = args.concat(mods); }
  if (unit && unit !== 'ALL') { sql += " AND (c4 = ? OR c4 = 'ALL')"; args.push(unit); }
  return db.prepare(sql + ' ORDER BY c3, c9, rid').all(args).map(function (r) { return C.eRow_([out(r.c1), out(r.c2), out(r.c3), out(r.c4), out(r.c5), out(r.c6), out(r.c7), out(r.c8), out(r.c9)]); });
};
/* lots: address rows by their key */
C.lotRows_ = function (unit) {
  return db.prepare('SELECT c1,c2,c3,c4,c5,c6,c7,c8 FROM Lots WHERE c3=? ORDER BY rid').all(unit).map(function (v) {
    return { row: String(v.c1), key: C.str_(v.c1), date: C.dkey_(v.c2), unit: C.str_(v.c3), type: C.str_(v.c4), cleared: C.num_(v.c5), log: C.jparse_(v.c6, []), by: C.str_(v.c7), at: C.str_(v.c8) };
  });
};
/* first start: create the Admin + staff logins and default settings (same as setup() in Google) */
let ready = false;
C.ensureSchema_ = function () {
  if (ready) return;
  db.transaction(function () {
    var props = PropertiesService.getScriptProperties();
    if (SHEETS.Users.getLastRow() < 2) {
      var rows = [['Admin', 'Admin', '1234', C.ALL_MODULES.join(','), true, 'UL,PC']];
      C.SEED_USERS.office.forEach(function (n) { rows.push([n, 'Staff', '1111', (n === 'Sunny' ? ['daily', 'staffErr'].concat(C.OFFICE_MODULES) : C.OFFICE_MODULES).join(','), true, 'UL']); });
      C.SEED_USERS.process.forEach(function (n) { rows.push([n, 'Staff', '1111', C.PROCESS_MODULES.join(','), true, 'UL']); });
      SHEETS.Users.getRange(2, 1, rows.length, 6).setValues(rows);
    }
    if (!SHEETS.Settings.find(1, 'app').length) SHEETS.Settings.appendRow(['app', JSON.stringify(C.DEFAULT_SETTINGS)]);
    if (!props.getProperty('SECRET')) props.setProperty('SECRET', crypto.randomBytes(48).toString('hex'));
  })();
  ready = true;
};
/* photos → data/photos/<id>.jpg */
C.photo_ = function (u, p) {
  if (!p.data) throw new Error('No photo');
  var id = 'P' + crypto.randomBytes(9).toString('hex'), buf = Buffer.from(String(p.data), 'base64');
  if (buf.length > 6 * 1024 * 1024) throw new Error('Photo too big');
  fs.writeFileSync(path.join(DATA, 'photos', id + '.jpg'), buf);
  return { id: id, url: '/photo/' + id };
};
C.backupStats_ = function () {
  var n = function (t) { return SHEETS[t].getLastRow() - 1; }, size = 0;
  try { size = fs.statSync(path.join(DATA, 'workshop.db')).size; } catch (e) { }
  return { entries: n('Entries'), daily: n('Daily'), lots: n('Lots'), log: n('Log'), users: n('Users'), cells: size, limit: 20 * 1024 * 1024 * 1024, db: true };
};
C.ensureSchema_();

/* ───────── daily backup — keeps 30 days in data/backups.
   Time from BACKUP_AT in .env (default 02:15; on a server that switches off at night use e.g. 19:45) ───────── */
function nightly() {
  var day = fmtDate(new Date(), TZ, 'yyyy-MM-dd'), f = path.join(DATA, 'backups', 'workshop-' + day + '.db');
  if (fs.existsSync(f)) return;
  db.backup(f).then(function () {
    var files = fs.readdirSync(path.join(DATA, 'backups')).filter(function (x) { return /^workshop-.*\.db$/.test(x); }).sort();
    files.slice(0, Math.max(0, files.length - 30)).forEach(function (x) { fs.unlinkSync(path.join(DATA, 'backups', x)); });
    console.log('backup saved', f);
  }).catch(function (e) { console.error('backup failed', e.message); });
}
const BACKUP_AT = /^\d\d:\d\d$/.test(process.env.BACKUP_AT || '') ? process.env.BACKUP_AT : '02:15';
function backupCheck() { if (fmtDate(new Date(), TZ, 'HH:mm') >= BACKUP_AT) nightly(); }
setInterval(backupCheck, 5 * 60 * 1000); setTimeout(backupCheck, 20 * 1000);

/* ───────── web server ───────── */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.jpg': 'image/jpeg', '.txt': 'text/plain' };
function send(res, code, body, type, extra) {
  var h = Object.assign({ 'Content-Type': type || 'application/json; charset=utf-8', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin' }, extra || {});
  res.writeHead(code, h); res.end(body);
}
const server = http.createServer(function (req, res) {
  var url = decodeURIComponent((req.url || '/').split('?')[0]);
  if (req.method === 'POST' && url === '/api') {
    var chunks = [], size = 0;
    req.on('data', function (c) { size += c.length; if (size > 30 * 1024 * 1024) { req.destroy(); return; } chunks.push(c); });
    req.on('end', function () {
      var body; try { body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); } catch (e) { return send(res, 400, JSON.stringify({ ok: false, error: 'Bad request' })); }
      var t0 = Date.now(), r = C.api(body);
      if (Date.now() - t0 > 1500) console.log('slow', body.action, Date.now() - t0, 'ms');
      send(res, 200, JSON.stringify(r), null, { 'Cache-Control': 'no-store' });
    });
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, '{}');
  var m = url.match(/^\/photo\/(P[a-f0-9]{18})$/);
  if (m) {
    var pf = path.join(DATA, 'photos', m[1] + '.jpg');
    if (!fs.existsSync(pf)) return send(res, 404, 'Not found', 'text/plain');
    return send(res, 200, fs.readFileSync(pf), 'image/jpeg', { 'Cache-Control': 'private, max-age=31536000, immutable' });
  }
  if (url === '/healthz') return send(res, 200, JSON.stringify({ ok: true, time: fmtDate(new Date(), TZ, 'yyyy-MM-dd HH:mm:ss') }));
  var file = path.normalize(path.join(PUBLIC, url === '/' ? 'index.html' : url));
  if (file.indexOf(path.normalize(PUBLIC)) !== 0) return send(res, 403, 'Forbidden', 'text/plain');
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(PUBLIC, 'index.html');   // app routes → the app
  var ext = path.extname(file), noCache = /index\.html$|sw\.js$|\.webmanifest$/.test(file);
  send(res, 200, fs.readFileSync(file), MIME[ext] || 'application/octet-stream', { 'Cache-Control': noCache ? 'no-cache' : 'public, max-age=86400' });
});
server.listen(PORT, process.env.HOST || '127.0.0.1', function () { console.log('Workshop Operational Control running on http://' + (process.env.HOST || '127.0.0.1') + ':' + PORT); });
process.on('SIGTERM', function () { server.close(); db.close(); process.exit(0); });
