#!/usr/bin/env bash
# Install a newer version — data is NOT touched.   sudo bash deploy/update.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"; APP=/opt/workshop
cp "$APP/server/.env" /tmp/workshop.env
rm -rf "$APP/public" && cp -r "$HERE/public" "$APP/"
cp "$HERE/server/server.js" "$HERE/server/Code.gs" "$HERE/server/package.json" "$APP/server/"
cp /tmp/workshop.env "$APP/server/.env"
cd "$APP/server" && npm install --omit=dev --no-audit --no-fund
chown -R workshop:workshop "$APP"
systemctl restart workshop && sleep 2 && curl -fsS http://127.0.0.1:8080/healthz && echo " ✓ updated"
