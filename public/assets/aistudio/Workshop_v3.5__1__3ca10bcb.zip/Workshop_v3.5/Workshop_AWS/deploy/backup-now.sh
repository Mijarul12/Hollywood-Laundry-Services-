#!/usr/bin/env bash
# Make an instant copy of the database:   sudo bash deploy/backup-now.sh
set -e; F=/var/lib/workshop/backups/manual-$(date +%Y%m%d-%H%M).db
sqlite3 /var/lib/workshop/workshop.db ".backup '$F'" && echo "✓ saved $F"
